%% MATLAB program to create stripes colormaps for the world in years (since 1850)

% AM230630 in R2017a 1st trial -> and success! -> based on:
% http://mres.uni-potsdam.de/index.php/2022/11/16/ed-hawkins-warming-stripes-with-matlab/
% AM230701 in R2023a further minor edits and development
% AM230708 in R2023a completion with more data and figure pairs

%% Acknowledgement

% NOVEMBER 16, 2022 BY MARTIN H. TRAUTH
% Ed Hawkins, Warming Stripes with MATLAB

% Ed Hawkins, climatologist at U Reading, published a visualization graphics for climate data to display global warming.
% Here's a script to display the warming stripes with MATLAB. To display the popular warming stripes, Python scripts and
% R scripts exist, but I was not able to find a MATLAB script, inspired by a discussion on Twitter. In following script
% I used the HadCRUT.4.6.0.0 dataset by the Met Office Hadley Centre. The hex colormap was taken from the Python script
% and converted to RGB colors using a script by Jos van der Geest published on the MathWorks File Exchange.

%% Housekeeping

% We first clear the workspace, clear the Command Window and close all Figure Windows.
clear; clc; close all

%% Loading the Dataset

% We then load the dataset and define the time interval.

%data = load('HadCRUT.4.6.0.0.annual_ns_avg.txt');
data = load('HadCRUT.5.0.1.0.analysis.summary_series.global.annual.txt');
ticks = 1851:4:2023; %AM230708 I added a step of 4 years in the middle (readable)
                     % also began the ticks from 1951 (not 1950), so that 2023 shows
                     % up at the end too (otherwise, if unticked, does not)!!!

%% Defining the Colormap

% We then create a colormap. These are the colors from the Python script cited above, converted with Jos van der Geest's
% MATLAB code to RGB colors, and then simply stored in the variable wscolors. Note that the colormap has 16 colors ->
% these can be increased/decreased (but will need respective RGB definitions)

wscolors = [
   0.0314 0.1882 0.4196
   0.0314 0.3176 0.6118
   0.1294 0.4431 0.7098
   0.2588 0.5725 0.7765
   0.4196 0.6824 0.8392
   0.6196 0.7922 0.8824
   0.7765 0.8588 0.9373
   0.8706 0.9216 0.9686
   0.9961 0.8784 0.8235
   0.9882 0.7333 0.6314
   0.9882 0.5725 0.4471
   0.9843 0.4157 0.2902
   0.9373 0.2314 0.1725
   0.7961 0.0941 0.1137
   0.6471 0.0588 0.0824
   0.4039 0      0.0510
];

%% Creating the Figures

% Finally, we create the graphics using imagesc. We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above, e.g. running from 1970 to 2022, rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticks) max(ticks)],...
   'XTickMode','manual',...
   'XTick',ticks,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticks',...
   'YData',[2000 2040],...
   'XData',[1850 2023],...
   'CData',data(:,2)')
colormap(wscolors)
colorbar
title('Deviation from Average World Temperature for 1960-1990 Normalized to 0');

saveas(gcf,'ATWsince1850annual.fig') %AM230701 checking online
saveas(gcf,'ATWsince1850annual.png')
saveas(gcf,'ATWsince1850annual.epsc')

%% References

% Hawkins, Ed (2018-12-04). ?2018 visualisation update / Warming stripes for 1850?2018 using the WMO annual global
% temperature dataset?. Climate Lab Book.

%% Plot

figure
plot(data(:,1),data(:,2),'LineWidth',2)
axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
grid on
xlabel('years (sample 1850-2023)')
ylabel('temperature anomaly, in degrees C from the mean for 1960-1990 at 0')
title('Deviation from Average World Temperature for 1960-1990 Normalized to 0');

saveas(gcf,'Plot_ATWsince1850annual.fig') %AM230701 checking online
saveas(gcf,'Plot_ATWsince1850annual.png')
saveas(gcf,'Plot_ATWsince1850annual.epsc')

%% Histogram

figure
histogram(data(:,2),16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('temperature anomaly, in degrees C from the mean for 1960-1990 at 0')
ylabel('frequency')
title('Deviation from Average World Temperature for 1960-1990 Normalized to 0');

%% Computation and Export of a Descriptive Stats Table

data_min = min(data(:,2))
data_max = max(data(:,2))
data_range = data_max - data_min
stripe_range = data_range/16
data_mean = mean(data(:,2))
data_median = median(data(:,2))
%data_mode = mode(data(:,2),'all') %AM230708 Sth's wrong about the mode command?!

saveas(gcf,'Hist_ATWsince1850annual.fig') %AM230701 checking online
saveas(gcf,'Hist_ATWsince1850annual.png')
saveas(gcf,'Hist_ATWsince1850annual.epsc')

tabClimateStripesReplication = table(categorical({'data_min';'data_max';'data_range';'stripe_range';'data_mean';'data_median'}),{data_min; data_max; data_range; stripe_range; data_mean; data_median})
writetable(tabClimateStripesReplication,'tabClimateStripesReplication.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")
