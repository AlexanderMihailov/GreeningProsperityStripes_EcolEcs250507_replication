%% MATLAB program to create stripes colormap of life expectancy in years for the World
% File name: LECO2pcWorldStripes_am231006.m
% AM230630 in R2017a 1st trial -> and success! -> based on:
% http://mres.uni-potsdam.de/index.php/2022/11/16/ed-hawkins-warming-stripes-with-matlab/
% AM230701 in R2023a minor edits and development
% AM230709 in R2023a further minor edits and development
% AM230720 in R2023a major development and addition of CO2 emissions and a brown-to-green colormap
% AM230720 in R2023a further improvenets and addition of greening prosperity ratio stripes
% AM231005 in R2023a switching to LE pc in PPP inernational USD of 2017 and addition of greening prosperity ratio stripes
% AM231006 in R2023a adding together World, HiIncCs, LoIncCs, US, EU, China
% AM231007 in R2023 trying (again) to fix the stripe colormaps in multiplots -> unsuccessful again (see the figure at the bottom of the code), but just fixed it in Overleaf/Beamer! 

%% Acknowledgement

% "NOVEMBER 16, 2022 BY MARTIN H. TRAUTH
% Ed Hawkins? Warming Stripes with MATLAB"

% "Ed Hawkins, climatologist at U Reading, published a visualization graphics for climate data to display global warming.
% Here's a script to display the warming stripes with MATLAB. To display the popular warming stripes, Python scripts and
% R scripts exist, but I was not able to find a MATLAB script, inspired by a discussion on Twitter. In following script
% I used the HadCRUT.4.6.0.0 dataset by the Met Office Hadley Centre. The hex colormap was taken from the Python script
% and converted to RGB colors using a script by Jos van der Geest published on the MathWorks File Exchange."

%% Housekeeping

% Clear the Workspace and the Command Window and close all Figure Windows (respectively,the 3 commands in the next line).
clear; clc; close all

diary LECO2pcStripes3Groups9Countries_am231017.txt % create a diary log (*.txt) file saving the output from the command window
tic                          % start stopwatch timer
t = datetime('now')          % return a datetime scalar representing the current date and time

%% Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEWorld = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI264:BM264');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEWorld = log(data_LEWorld);
dldata_LEWorld = diff(ldata_LEWorld)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcWorldMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI264:BM264');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcWorldMetricTons = log(data_CO2pcWorldMetricTons);
dldata_CO2pcWorldMetricTons = diff(ldata_CO2pcWorldMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcWorldDefByLE = data_LEWorld ./ data_CO2pcWorldMetricTons;
ticksGreenProsppcWorldLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcWorldDefByLE = log(data_GreenProsppcWorldDefByLE);
dldata_GreenProsppcWorldDefByLE = diff(ldata_GreenProsppcWorldDefByLE)*100;
ticksdlGreenProsppcWorldLE = 1991:2020;

%% Creating the Colormaps (16 colours, as per their RGB 3-vector code for each color below)

% The colors below are from the Python script cited above, converted with Jos van der Geest's MATLAB code to RGB colors,
% and then stored in the variable wscolors (next).

wscolors_EHWarming_BlueToRed = [
   0.0314 0.1882 0.4196
   0.0314 0.3176 0.6118
   0.1294 0.4431 0.7098
   0.2588 0.5725 0.7765
   0.4196 0.6824 0.8392
   0.6196 0.7922 0.8824
   0.7765 0.8588 0.9373
   0.8706 0.9216 0.9686
   0.9961 0.8784 0.8235
   0.9882 0.7333 0.6314
   0.9882 0.5725 0.4471
   0.9843 0.4157 0.2902
   0.9373 0.2314 0.1725
   0.7961 0.0941 0.1137
   0.6471 0.0588 0.0824
   0.4039 0 0.0510
];

%AM230720 The colors below were chosen by me for the greening prosperity stripes

wscolors_AMGreening_BrownToGreen = [
140/255 70/255 20/255
170/255 90/255 40/255
200/255 110/255 60/255
210/255 130/255 80/255
220/255 150/255 100/255
230/255 170/255 140/255
240/255 200/255 200/255
253/255 245/255 230/255 %AM230725 Note that I chose all 3 R, G and B in the RGB triplet to increase gradually (top-down) for the Brown nuances as they get lighter
240/255 255/255 220/255
195/255 250/255 160/255
170/255 240/255 150/255
140/255 225/255 140/255
120/255 210/255 120/255
60/255 170/255 100/255
30/255 135/255 50/255
0/255 100/255 0/255     %AM230725 Note that I chose all 3 R, G and B in the RGB triplet to increase gradually (bottom-up) for the Green nuances as they get lighter
];

%AM231005 I had to reverse the above scale to capture the CO2 emisiions dynamics/time series trend!

wscolors_AMGreening_GreenToBrown = [
0/255 100/255 0/255
30/255 135/255 50/255
60/255 170/255 100/255
120/255 210/255 120/255
140/255 225/255 140/255
170/255 240/255 150/255
195/255 250/255 160/255
240/255 255/255 220/255
253/255 245/255 230/255
240/255 200/255 200/255
230/255 170/255 140/255
220/255 150/255 100/255
210/255 130/255 80/255
200/255 110/255 60/255
170/255 90/255 40/255
140/255 70/255 20/255
];

%% Creating the World LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig1 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEWorld)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('Average World LE per capita in PPP International USD of 2017 for 1990-1990');
title('World');

saveas(gcf,'LEWpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEWpcAbs.png')
saveas(gcf,'LEWpcAbs.epsc')

LEWpcDev = imread('LEWpcAbs.png'); %AM230701 after checking online

%% "References

% Hawkins, Ed (2018-12-04). 2018 visualisation update / Warming stripes for 1850?2018 using the WMO annual global
% temperature dataset. Climate Lab Book."

%% Plot - absolute level

fig2 = figure
plot(ticksLE,data_LEWorld,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average world LE per capita in PPP international USD of 2017')
title('Average World LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEWorldAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEWorldAbsSince1990Annual.png')
saveas(gcf,'Plot_LEWorldAbsSince1990Annual.epsc')

%% Plot - growth rates

fig3 = figure
plot(ticksdlLE,dldata_LEWorld,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of average world LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of Average World LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEWorldAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEWorldAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEWorldAbsSince1990Annual.epsc')

%% Histogram - absolute level

fig4 = figure
histogram(data_LEWorld,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average World LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEWorldAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEWorldAbsSince1990Annual.png')
saveas(gcf,'Hist_LEWorldAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig5 = figure
histogram(dldata_LEWorld,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of Average World LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEWorldAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEWorldAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEWorldAbsSince1990Annual.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEWorldAbs_min = min(data_LEWorld);
data_LEWorldAbs_max = max(data_LEWorld);
data_LEWorldAbs_range = data_LEWorldAbs_max - data_LEWorldAbs_min;
stripe_LEWorldAbs_range = data_LEWorldAbs_range/16;
data_LEWorldAbs_mean = mean(data_LEWorld);
data_LEWorldAbs_median = median(data_LEWorld);
%data_LEWorldAbs_mode = mode(data_LEWorld,'all'); %AM230708 Sth's wrong about the mode command?!
data_LEWorldAbs_std = std(data_LEWorld);

tabLEWorldAbs = table(categorical({'data_LEWorldAbs_min';'data_LEWorldAbs_max';'data_LEWorldAbs_range';'stripe_LEWorldAbs_range';'data_LEWorldAbs_mean';'data_LEWorldAbs_median'; 'data_LEWorldAbs_std'}),{data_LEWorldAbs_min; data_LEWorldAbs_max; data_LEWorldAbs_range; stripe_LEWorldAbs_range; data_LEWorldAbs_mean; data_LEWorldAbs_median; data_LEWorldAbs_std});
writetable(tabLEWorldAbs,'tabLEWorldUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEWorldAbs_min = min(dldata_LEWorld);
dldata_LEWorldAbs_max = max(dldata_LEWorld);
dldata_LEWorldAbs_range = dldata_LEWorldAbs_max - dldata_LEWorldAbs_min;
dlstripe_LEWorldAbs_range = dldata_LEWorldAbs_range/16;
dldata_LEWorldAbs_mean = mean(dldata_LEWorld);
dldata_LEWorldAbs_median = median(dldata_LEWorld);
%dldata_LEWorldAbs_mode = mode(dldata_LEWorld,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEWorldAbs_std = std(dldata_LEWorld);

tabdlLEWorldAbs = table(categorical({'dldata_LEWorldAbs_min';'dldata_LEWorldAbs_max';'dldata_LEWorldAbs_range';'dlstripe_LEWorldAbs_range';'dldata_LEWorldAbs_mean';'dldata_LEWorldAbs_median'; 'dldata_LEWorldAbs_std'}),{dldata_LEWorldAbs_min; dldata_LEWorldAbs_max; dldata_LEWorldAbs_range; stripe_LEWorldAbs_range; dldata_LEWorldAbs_mean; dldata_LEWorldAbs_median; dldata_LEWorldAbs_std});
writetable(tabdlLEWorldAbs,'tabdlLEWorldUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the World CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig6 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcWorldMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('Average World CO2 Emissions per capita for 1990-2020');
title('World');

saveas(gcf,'CO2WpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2WpcAbs.png')
saveas(gcf,'CO2WpcAbs.epsc')

CO2WpcAbs = imread('CO2WpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig7 = figure
plot(ticksCO2,data_CO2pcWorldMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average world CO2 emissions pc, in metric tons')
title('Average World CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcWorldMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcWorldMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcWorldMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig8 = figure
plot(ticksdlCO2,dldata_CO2pcWorldMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of average world CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of Average World CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcWorldMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcWorldMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcWorldMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig9 = figure
histogram(data_CO2pcWorldMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average World CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcWorldMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcWorldMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcWorldMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig10 = figure
histogram(dldata_CO2pcWorldMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of Average World CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcWorldMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcWorldMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcWorldMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcWorldMetricTonsAbs_min = min(data_CO2pcWorldMetricTons);
data_CO2pcWorldMetricTonsAbs_max = max(data_CO2pcWorldMetricTons);
data_CO2pcWorldMetricTonsAbs_range = data_CO2pcWorldMetricTonsAbs_max - data_CO2pcWorldMetricTonsAbs_min;
stripe_CO2pcWorldMetricTonsAbs_range = data_CO2pcWorldMetricTonsAbs_range/16;
data_CO2pcWorldMetricTonsAbs_mean = mean(data_CO2pcWorldMetricTons);
data_CO2pcWorldMetricTonsAbs_median = median(data_CO2pcWorldMetricTons);
%data_CO2pcWorldMetricTonsAbs_mode = mode(data_CO2pcWorldMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
data_CO2pcWorldMetricTonsAbs_std = std(data_CO2pcWorldMetricTons);

tabCO2pcWorldMetricTonsAbs = table(categorical({'data_CO2pcWorldMetricTonsAbs_min';'data_CO2pcWorldMetricTonsAbs_max';'data_CO2pcWorldMetricTons_range';'stripe_CO2pcWorldMetricTonsAbs_range';'data_CO2pcWorldMetricTonsAbs_mean';'data_CO2pcWorldMetricTonsAbs_median'; 'data_CO2pcWorldMetricTonsAbs_std'}),{data_CO2pcWorldMetricTonsAbs_min; data_CO2pcWorldMetricTonsAbs_max; data_CO2pcWorldMetricTonsAbs_range; stripe_CO2pcWorldMetricTonsAbs_range; data_CO2pcWorldMetricTonsAbs_mean; data_CO2pcWorldMetricTonsAbs_median; data_CO2pcWorldMetricTonsAbs_std});
writetable(tabCO2pcWorldMetricTonsAbs,'tabCO2pcWorldMetricTonsAbs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeneingProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcWorldMetricTonsAbs_min = min(dldata_CO2pcWorldMetricTons);
dldata_CO2pcWorldMetricTonsAbs_max = max(dldata_CO2pcWorldMetricTons);
dldata_CO2pcWorldMetricTonsAbs_range = dldata_CO2pcWorldMetricTonsAbs_max - dldata_CO2pcWorldMetricTonsAbs_min;
dlstripe_CO2pcWorldMetricTonsAbs_range = dldata_CO2pcWorldMetricTonsAbs_range/16;
dldata_CO2pcWorldMetricTonsAbs_mean = mean(dldata_CO2pcWorldMetricTons);
dldata_CO2pcWorldMetricTonsAbs_median = median(dldata_CO2pcWorldMetricTons);
%dldata_CO2pcWorldMetricTonsAbs_mode = mode(dldata_CO2pcWorldMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcWorldMetricTonsAbs_std = std(dldata_CO2pcWorldMetricTons);

tabdlCO2pcWorldMetricTonsAbs = table(categorical({'data_CO2pcWorldMetricTonsAbs_min';'data_CO2pcWorldMetricTonsAbs_max';'data_CO2pcWorldMetricTons_range';'stripe_CO2pcWorldMetricTonsAbs_range';'data_CO2pcWorldMetricTonsAbs_mean';'data_CO2pcWorldMetricTonsAbs_median'; 'dldata_CO2pcWorldMetricTonsAbs_std'}),{data_CO2pcWorldMetricTonsAbs_min; data_CO2pcWorldMetricTonsAbs_max; data_CO2pcWorldMetricTonsAbs_range; stripe_CO2pcWorldMetricTonsAbs_range; data_CO2pcWorldMetricTonsAbs_mean; data_CO2pcWorldMetricTonsAbs_median; dldata_CO2pcWorldMetricTonsAbs_std})
writetable(tabdlCO2pcWorldMetricTonsAbs,'tabdlCO2pcWorldMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the World Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig11 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProsppcWorldLE) max(ticksGreenProsppcWorldLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProsppcWorldLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProsppcWorldLE',...
   'YData',[2000 2040],...c
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcWorldDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('Average World Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('World');

saveas(gcf,'GreenProsppcDefLEPPPUSD2017WorldAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProsppcDefLEPPPUSD2017WorldAbs.png')
saveas(gcf,'GreenProsppcDefLEPPPUSD2017WorldAbs.epsc')

GreenProsppcDefLEPPPUSD2017WpcAbs = imread('GreenProsppcDefLEPPPUSD2017WorldAbs.png'); %AM230701 after checking online

%% Plot - absolute level

fig12 = figure
plot(ticksGreenProsppcWorldLE,data_GreenProsppcWorldDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average world greening prosperity ratio pc (LE pc / CO2 pc)')
title('Average World Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017WorldAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017WorldAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017WorldAbs.epsc')

%% Plot - growth rates

fig13 = figure
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcWorldDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth ratess (in % pa) of average world greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa)of Average World Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017WorldAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017WorldAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017WorldAbs.epsc')

%% Histogram - absolute level

fig14 = figure
histogram(data_GreenProsppcWorldDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average World Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017WorldAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017WorldAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017WorldAbs.epsc')

%% Histogram - growth rates

fig15 = figure
histogram(dldata_GreenProsppcWorldDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of Average World Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017WorldAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017WorldAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017WorldAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcWorldDefByLEAbs_min = min(data_GreenProsppcWorldDefByLE);
data_GreenProsppcWorldDefByLEAbs_max = max(data_GreenProsppcWorldDefByLE);
data_GreenProsppcWorldDefByLEAbs_range = data_GreenProsppcWorldDefByLEAbs_max - data_GreenProsppcWorldDefByLEAbs_min;
stripe_GreenProsppcWorldDefByLEAbs_range = data_GreenProsppcWorldDefByLEAbs_range/16;
data_GreenProsppcWorldDefByLEAbs_mean = mean(data_GreenProsppcWorldDefByLE);
data_GreenProsppcWorldDefByLEAbs_median = median(data_GreenProsppcWorldDefByLE);
%data_GreenProsppcWorldDefByLEAbs_mode = mode(data_GreenProsppcWorldDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcWorldDefByLEAbs_std = std(data_GreenProsppcWorldDefByLE);

tabGreenProsppcWorldDefByLEAbs = table(categorical({'data_GreenProsppcWorldDefByLEAbs_min';'data_GreenProsppcWorldDefByLEAbs_max';'data_GreenProsppcWorldDefByLE_range';'stripe_CO2pcWorldMetricTonsAbs_range';'data_GreenProsppcWorldDefByLEAbs_mean';'data_GreenProsppcWorldDefByLEAbs_median'; 'data_GreenProsppcWorldDefByLEAbs_std'}),{data_GreenProsppcWorldDefByLEAbs_min; data_GreenProsppcWorldDefByLEAbs_max; data_GreenProsppcWorldDefByLEAbs_range; stripe_CO2pcWorldMetricTonsAbs_range; data_GreenProsppcWorldDefByLEAbs_mean; data_GreenProsppcWorldDefByLEAbs_median; data_GreenProsppcWorldDefByLEAbs_std});
writetable(tabGreenProsppcWorldDefByLEAbs ,'tabGreenProsppcWorldDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcWorldDefByLEAbs_min = min(dldata_GreenProsppcWorldDefByLE);
dldata_GreenProsppcWorldDefByLEAbs_max = max(dldata_GreenProsppcWorldDefByLE);
dldata_GreenProsppcWorldDefByLEAbs_range = dldata_GreenProsppcWorldDefByLEAbs_max - dldata_GreenProsppcWorldDefByLEAbs_min;
dlstripe_GreenProsppcWorldDefByLEAbs_range = dldata_GreenProsppcWorldDefByLEAbs_range/16;
dldata_GreenProsppcWorldDefByLEAbs_mean = mean(dldata_GreenProsppcWorldDefByLE);
dldata_GreenProsppcWorldDefByLEAbs_median = median(dldata_GreenProsppcWorldDefByLE);
%dldata_GreenProsppcWorldDefByLEAbs_mode = mode(dldata_GreenProsppcWorldDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcWorldDefByLEAbs_std = std(dldata_GreenProsppcWorldDefByLE);

tabdlGreenProsppcWorldDefByLEAbs = table(categorical({'dldata_GreenProsppcWorldDefByLEAbs_min';'dldata_GreenProsppcWorldDefByLEAbs_max';'dldata_GreenProsppcWorldDefByLE_range';'dlstripe_CO2pcWorldMetricTonsAbs_range';'dldata_GreenProsppcWorldDefByLEAbs_mean';'dldata_GreenProsppcWorldDefByLEAbs_median'; 'dldata_GreenProsppcWorldDefByLEAbs_std'}),{dldata_GreenProsppcWorldDefByLEAbs_min; dldata_GreenProsppcWorldDefByLEAbs_max; dldata_GreenProsppcWorldDefByLEAbs_range; dlstripe_CO2pcWorldMetricTonsAbs_range; dldata_GreenProsppcWorldDefByLEAbs_mean; dldata_GreenProsppcWorldDefByLEAbs_median; dldata_GreenProsppcWorldDefByLEAbs_std});
writetable(tabdlGreenProsppcWorldDefByLEAbs ,'tabdlGreenProsppcWorldDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% High Income Countries - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEHiIncCs = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI100:BM100');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEHiIncCs = log(data_LEHiIncCs);
dldata_LEHiIncCs = diff(ldata_LEHiIncCs)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcHiIncCsMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI100:BM100');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcHiIncCsMetricTons = log(data_CO2pcHiIncCsMetricTons);
dldata_CO2pcHiIncCsMetricTons = diff(ldata_CO2pcHiIncCsMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcHiIncCsDefByLE = data_LEHiIncCs ./ data_CO2pcHiIncCsMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcHiIncCsDefByLE = log(data_GreenProsppcHiIncCsDefByLE);
dldata_GreenProsppcHiIncCsDefByLE = diff(ldata_GreenProsppcHiIncCsDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the HiIncCs LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig16 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEHiIncCs)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('Average High-Income Countries LE per capita in PPP International USD of 2017 for 1990-1990');
title('High-Income Cs');

saveas(gcf,'LEHiIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'LEHiIncCspcAbs.png')
saveas(gcf,'LEHiIncCspcAbs.epsc')

LEHiIncCspcDev = imread('LEHiIncCspcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig17 = figure
plot(ticksLE,data_LEHiIncCs,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average high-income countries LE per capita in PPP international USD of 2017')
title('Average High-Income Countries LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEHiIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEHiIncCsAbsSince1990Annual.png')
saveas(gcf,'Plot_LEHiIncCsAbsSince1990Annual.epsc')


%% Plot - growth rates

fig18 = figure
plot(ticksdlLE,dldata_LEHiIncCs,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of average high-income countries LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of Average High-Income Countries LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEHiIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEHiIncCsAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEHiIncCsAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig19 = figure
histogram(data_LEHiIncCs,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average High-Income Countries LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEHiIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEHiIncCsAbsSince1990Annual.png')
saveas(gcf,'Hist_LEHiIncCsAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig20 = figure
histogram(dldata_LEHiIncCs,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of Average High-Income Countries LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEHiIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEHiIncCsAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEHiIncCsAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEHiIncCsAbs_min = min(data_LEHiIncCs)
data_LEHiIncCsAbs_max = max(data_LEHiIncCs)
data_LEHiIncCsAbs_range = data_LEHiIncCsAbs_max - data_LEHiIncCsAbs_min
stripe_LEHiIncCsAbs_range = data_LEHiIncCsAbs_range/16
data_LEHiIncCsAbs_mean = mean(data_LEHiIncCs)
data_LEHiIncCsAbs_median = median(data_LEHiIncCs)
%data_LEHiIncCsAbs_mode = mode(data_LEHiIncCs,'all') %AM230708 Sth's wrong about the mode command?!

tabLEHiIncCsAbs = table(categorical({'data_LEHiIncCsAbs_min';'data_LEHiIncCsAbs_max';'data_LEHiIncCsAbs_range';'stripe_LEHiIncCsAbs_range';'data_LEHiIncCsAbs_mean';'data_LEHiIncCsAbs_median'}),{data_LEHiIncCsAbs_min; data_LEHiIncCsAbs_max; data_LEHiIncCsAbs_range; stripe_LEHiIncCsAbs_range; data_LEHiIncCsAbs_mean; data_LEHiIncCsAbs_median})
writetable(tabLEHiIncCsAbs,'tabLEHiIncCsUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEHiIncCsAbs_min = min(dldata_LEHiIncCs);
dldata_LEHiIncCsAbs_max = max(dldata_LEHiIncCs);
dldata_LEHiIncCsAbs_range = dldata_LEHiIncCsAbs_max - dldata_LEHiIncCsAbs_min;
dlstripe_LEHiIncCsAbs_range = dldata_LEHiIncCsAbs_range/16;
dldata_LEHiIncCsAbs_mean = mean(dldata_LEHiIncCs);
dldata_LEHiIncCsAbs_median = median(dldata_LEHiIncCs);
%dldata_LEHiIncCsAbs_mode = mode(dldata_LEHiIncCs,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEHiIncCsAbs_std = std(dldata_LEHiIncCs);

tabdlLEHiIncCsAbs = table(categorical({'dldata_LEHiIncCsAbs_min';'dldata_LEHiIncCsAbs_max';'dldata_LEHiIncCsAbs_range';'dlstripe_LEHiIncCsAbs_range';'dldata_LEHiIncCsAbs_mean';'dldata_LEHiIncCsAbs_median'; 'dldata_LEHiIncCsAbs_std'}),{dldata_LEHiIncCsAbs_min; dldata_LEHiIncCsAbs_max; dldata_LEHiIncCsAbs_range; stripe_LEHiIncCsAbs_range; dldata_LEHiIncCsAbs_mean; dldata_LEHiIncCsAbs_median; dldata_LEHiIncCsAbs_std});
writetable(tabdlLEHiIncCsAbs,'tabdlLEHiIncCsUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the HiIncCs CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig21 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcHiIncCsMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('Average CO2 Emissions in the High-Income Countries per capita for 1990-2020');
title('High-Income Cs');

saveas(gcf,'CO2HiIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2HiIncCspcAbs.png')
saveas(gcf,'CO2HiIncCspcAbs.epsc')

CO2HiIncCspcAbs = imread('CO2HiIncCspcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig22 = figure
plot(ticksCO2,data_CO2pcHiIncCsMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average high-income countries CO2 emissions pc, in metric tons')
title('Average High-Income Countries CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcHiIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcHiIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcHiIncCsMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig23 = figure
plot(ticksdlCO2,dldata_CO2pcHiIncCsMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of average high-income countries CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of Average High-Income Countries CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcHiIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcHiIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcHiIncCsMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig24 = figure
histogram(data_CO2pcHiIncCsMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average High-Income Countries CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcHiIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcHiIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcHiIncCsMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig25 = figure
histogram(dldata_CO2pcHiIncCsMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of Average High-Income Countries CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcHiIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcHiIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcHiIncCsMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcHiIncCsMetricTonsAbs_min = min(data_CO2pcHiIncCsMetricTons)
data_CO2pcHiIncCsMetricTonsAbs_max = max(data_CO2pcHiIncCsMetricTons)
data_CO2pcHiIncCsMetricTonsAbs_range = data_CO2pcHiIncCsMetricTonsAbs_max - data_CO2pcHiIncCsMetricTonsAbs_min
stripe_CO2pcHiIncCsMetricTonsAbs_range = data_CO2pcHiIncCsMetricTonsAbs_range/16
data_CO2pcHiIncCsMetricTonsAbs_mean = mean(data_CO2pcHiIncCsMetricTons)
data_CO2pcHiIncCsMetricTonsAbs_median = median(data_CO2pcHiIncCsMetricTons)
%data_CO2pcHiIncCsMetricTonsAbs_mode = mode(data_CO2pcHiIncCsMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcHiIncCsMetricTonsAbs = table(categorical({'data_CO2pcHiIncCsMetricTonsAbs_min';'data_CO2pcHiIncCsMetricTonsAbs_max';'data_CO2pcHiIncCsMetricTons_range';'stripe_CO2pcHiIncCsMetricTonsAbs_range';'data_CO2pcHiIncCsMetricTonsAbs_mean';'data_CO2pcHiIncCsMetricTonsAbs_median'}),{data_CO2pcHiIncCsMetricTonsAbs_min; data_CO2pcHiIncCsMetricTonsAbs_max; data_CO2pcHiIncCsMetricTonsAbs_range; stripe_CO2pcHiIncCsMetricTonsAbs_range; data_CO2pcHiIncCsMetricTonsAbs_mean; data_CO2pcHiIncCsMetricTonsAbs_median})
writetable(tabCO2pcHiIncCsMetricTonsAbs,'tabCO2pcHiIncCsMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcHiIncCsMetricTonsAbs_min = min(dldata_CO2pcHiIncCsMetricTons);
dldata_CO2pcHiIncCsMetricTonsAbs_max = max(dldata_CO2pcHiIncCsMetricTons);
dldata_CO2pcHiIncCsMetricTonsAbs_range = dldata_CO2pcHiIncCsMetricTonsAbs_max - dldata_CO2pcHiIncCsMetricTonsAbs_min;
dlstripe_CO2pcHiIncCsMetricTonsAbs_range = dldata_CO2pcHiIncCsMetricTonsAbs_range/16;
dldata_CO2pcHiIncCsMetricTonsAbs_mean = mean(dldata_CO2pcHiIncCsMetricTons);
dldata_CO2pcHiIncCsMetricTonsAbs_median = median(dldata_CO2pcHiIncCsMetricTons);
%dldata_CO2pcHiIncCsMetricTonsAbs_mode = mode(dldata_CO2pcHiIncCsMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcHiIncCsMetricTonsAbs_std = std(dldata_CO2pcHiIncCsMetricTons);

tabdlCO2pcHiIncCsMetricTonsAbs = table(categorical({'data_CO2pcHiIncCsMetricTonsAbs_min';'data_CO2pcHiIncCsMetricTonsAbs_max';'data_CO2pcHiIncCsMetricTons_range';'stripe_CO2pcHiIncCsMetricTonsAbs_range';'data_CO2pcHiIncCsMetricTonsAbs_mean';'data_CO2pcHiIncCsMetricTonsAbs_median'; 'dldata_CO2pcHiIncCsMetricTonsAbs_std'}),{data_CO2pcHiIncCsMetricTonsAbs_min; data_CO2pcHiIncCsMetricTonsAbs_max; data_CO2pcHiIncCsMetricTonsAbs_range; stripe_CO2pcHiIncCsMetricTonsAbs_range; data_CO2pcHiIncCsMetricTonsAbs_mean; data_CO2pcHiIncCsMetricTonsAbs_median; dldata_CO2pcHiIncCsMetricTonsAbs_std})
writetable(tabdlCO2pcHiIncCsMetricTonsAbs,'tabdlCO2pcHiIncCsMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the HiIncCs Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig26 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcHiIncCsDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('Average High-Income Countries Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020')
title('High-Income Cs');

saveas(gcf,'GreenProspDefLEPPPUSD2017HiIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017HiIncCspcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017HiIncCspcAbs.epsc')

CO2HiIncCspcAbs = imread('CO2HiIncCspcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig27 = figure
plot(ticksGreenProspLE,data_GreenProsppcHiIncCsDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average high-income countries greening prosperity ratio pc (LE pc / CO2 pc)')
title('Average High-Income Countries Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017HiIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017HiIncCspcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017HiIncCspcAbs.epsc')

%% Plot - growth rates

fig28 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcHiIncCsDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of average high-income countries greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of Average High-Income Countries Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017HiIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017HiIncCspcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017HiIncCspcAbs.epsc')


%% Histogram - absolute level

fig29 = figure
histogram(data_GreenProsppcHiIncCsDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average High-Income Countries Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017HiIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017HiIncCspcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017HiIncCspcAbs.epsc')

%% Histogram - growth rates

fig30 = figure
histogram(dldata_GreenProsppcHiIncCsDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of Average High-Income Countries Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017HiIncCsAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017HiIncCsAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017HiIncCsAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcHiIncCsDefByLEAbs_min = min(data_GreenProsppcHiIncCsDefByLE);
data_GreenProsppcHiIncCsDefByLEAbs_max = max(data_GreenProsppcHiIncCsDefByLE);
data_GreenProsppcHiIncCsDefByLEAbs_range = data_GreenProsppcHiIncCsDefByLEAbs_max - data_GreenProsppcHiIncCsDefByLEAbs_min;
stripe_GreenProsppcHiIncCsDefByLEAbs_range = data_GreenProsppcHiIncCsDefByLEAbs_range/16;
data_GreenProsppcHiIncCsDefByLEAbs_mean = mean(data_GreenProsppcHiIncCsDefByLE);
data_GreenProsppcHiIncCsDefByLEAbs_median = median(data_GreenProsppcHiIncCsDefByLE);
%data_GreenProsppcHiIncCsDefByLEAbs_mode = mode(data_GreenProsppcHiIncCsDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcHiIncCsDefByLEAbs_std = std(data_GreenProsppcHiIncCsDefByLE);

tabGreenProsppcHiIncCsDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcHiIncCsDefByLEAbs_min';'data_GreenProsppcHiIncCsDefByLEAbs_max';'data_GreenProsppcHiIncCsDefByLE_range';'stripe_GreenProsppcHiIncCsDefByLEAbs_range';'data_GreenProsppcHiIncCsDefByLEAbs_mean';'data_GreenProsppcHiIncCsDefByLEAbs_median'; 'data_GreenProsppcHiIncCsDefByLEAbs_std'}),{data_GreenProsppcHiIncCsDefByLEAbs_min; data_GreenProsppcHiIncCsDefByLEAbs_max; data_GreenProsppcHiIncCsDefByLEAbs_range; stripe_GreenProsppcHiIncCsDefByLEAbs_range; data_GreenProsppcHiIncCsDefByLEAbs_mean; data_GreenProsppcHiIncCsDefByLEAbs_median; data_GreenProsppcHiIncCsDefByLEAbs_std});
writetable(tabGreenProsppcHiIncCsDefByLEPPPIntUSDof2017Abs,'tabGreenProsppcHiIncCsDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcHiIncCsDefByLEAbs_min = min(dldata_GreenProsppcHiIncCsDefByLE);
dldata_GreenProsppcHiIncCsDefByLEAbs_max = max(dldata_GreenProsppcHiIncCsDefByLE);
dldata_GreenProsppcHiIncCsDefByLEAbs_range = dldata_GreenProsppcHiIncCsDefByLEAbs_max - dldata_GreenProsppcHiIncCsDefByLEAbs_min;
dlstripe_GreenProsppcHiIncCsDefByLEAbs_range = dldata_GreenProsppcHiIncCsDefByLEAbs_range/16;
dldata_GreenProsppcHiIncCsDefByLEAbs_mean = mean(dldata_GreenProsppcHiIncCsDefByLE);
dldata_GreenProsppcHiIncCsDefByLEAbs_median = median(dldata_GreenProsppcHiIncCsDefByLE);
%dldata_GreenProsppcHiIncCsDefByLEAbs_mode = mode(dldata_GreenProsppcHiIncCsDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcHiIncCsDefByLEAbs_std = std(dldata_GreenProsppcHiIncCsDefByLE);

tabdlGreenProsppcHiIncCsDefByLEAbs = table(categorical({'dldata_GreenProsppcHiIncCsDefByLEAbs_min';'dldata_GreenProsppcHiIncCsDefByLEAbs_max';'dldata_GreenProsppcHiIncCsDefByLE_range';'dlstripe_GreenProsppcHiIncCsDefByLEAbs_range';'dldata_GreenProsppcHiIncCsDefByLEAbs_mean'; 'dldata_GreenProsppcHiIncCsDefByLEAbs_median';'dldata_GreenProsppcHiIncCsDefByLEAbs_std'}),{dldata_GreenProsppcHiIncCsDefByLEAbs_min; dldata_GreenProsppcHiIncCsDefByLEAbs_max; dldata_GreenProsppcHiIncCsDefByLEAbs_range; dlstripe_GreenProsppcHiIncCsDefByLEAbs_range; dldata_GreenProsppcHiIncCsDefByLEAbs_mean; dldata_GreenProsppcHiIncCsDefByLEAbs_median; dldata_GreenProsppcHiIncCsDefByLEAbs_std});
writetable(tabdlGreenProsppcHiIncCsDefByLEAbs ,'tabdlGreenProsppcHiIncCsDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Low-Income Countries - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LELoIncCs = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI141:BM141');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LELoIncCs = log(data_LELoIncCs);
dldata_LELoIncCs = diff(ldata_LELoIncCs)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcLoIncCsMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI141:BM141');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcLoIncCsMetricTons = log(data_CO2pcLoIncCsMetricTons);
dldata_CO2pcLoIncCsMetricTons = diff(ldata_CO2pcLoIncCsMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcLoIncCsDefByLE = data_LELoIncCs ./ data_CO2pcLoIncCsMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcLoIncCsDefByLE = log(data_GreenProsppcLoIncCsDefByLE);
dldata_GreenProsppcLoIncCsDefByLE = diff(ldata_GreenProsppcLoIncCsDefByLE)*100;
ticksdlGreenProsppcLoIncCsLE = 1991:2020;

%% Creating the LoIncCs LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig31 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LELoIncCs)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('Average Low-Income Countries LE per capita in PPP International USD of 2017 for 1990-1990');
title('Low-Income Cs');

saveas(gcf,'LELoIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'LELoIncCspcAbs.png')
saveas(gcf,'LELoIncCspcAbs.epsc')

LELoIncCspcDev = imread('LELoIncCspcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig32 = figure
plot(ticksLE,data_LELoIncCs,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average low-income countries LE per capita in PPP international USD of 2017')
title('Average Low-Income Countries LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LELoIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LELoIncCsAbsSince1990Annual.png')
saveas(gcf,'Plot_LELoIncCsAbsSince1990Annual.epsc')


%% Plot - growth rates

fig33 = figure
plot(ticksdlLE,dldata_LELoIncCs,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of average low-income countries LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of Average Low-Income Countries LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLELoIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLELoIncCsAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLELoIncCsAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig34 = figure
histogram(data_LELoIncCs,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average Low-Income Countries LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LELoIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LELoIncCsAbsSince1990Annual.png')
saveas(gcf,'Hist_LELoIncCsAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig35 = figure
histogram(dldata_LELoIncCs,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of Average Low-Income Countries LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLELoIncCsAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLELoIncCsAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLELoIncCsAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LELoIncCsAbs_min = min(data_LELoIncCs)
data_LELoIncCsAbs_max = max(data_LELoIncCs)
data_LELoIncCsAbs_range = data_LELoIncCsAbs_max - data_LELoIncCsAbs_min
stripe_LELoIncCsAbs_range = data_LELoIncCsAbs_range/16
data_LELoIncCsAbs_mean = mean(data_LELoIncCs)
data_LELoIncCsAbs_median = median(data_LELoIncCs)
%data_LELoIncCsAbs_mode = mode(data_LELoIncCs,'all') %AM230708 Sth's wrong about the mode command?!

tabLELoIncCsAbs = table(categorical({'data_LELoIncCsAbs_min';'data_LELoIncCsAbs_max';'data_LELoIncCsAbs_range';'stripe_LELoIncCsAbs_range';'data_LELoIncCsAbs_mean';'data_LELoIncCsAbs_median'}),{data_LELoIncCsAbs_min; data_LELoIncCsAbs_max; data_LELoIncCsAbs_range; stripe_LELoIncCsAbs_range; data_LELoIncCsAbs_mean; data_LELoIncCsAbs_median})
writetable(tabLELoIncCsAbs,'tabLELoIncCsUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LELoIncCsAbs_min = min(dldata_LELoIncCs);
dldata_LELoIncCsAbs_max = max(dldata_LELoIncCs);
dldata_LELoIncCsAbs_range = dldata_LELoIncCsAbs_max - dldata_LELoIncCsAbs_min;
dlstripe_LELoIncCsAbs_range = dldata_LELoIncCsAbs_range/16;
dldata_LELoIncCsAbs_mean = mean(dldata_LELoIncCs);
dldata_LELoIncCsAbs_median = median(dldata_LELoIncCs);
%dldata_LELoIncCsAbs_mode = mode(dldata_LELoIncCs,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LELoIncCsAbs_std = std(dldata_LELoIncCs);

tabdlLELoIncCsAbs = table(categorical({'dldata_LELoIncCsAbs_min';'dldata_LELoIncCsAbs_max';'dldata_LELoIncCsAbs_range';'dlstripe_LELoIncCsAbs_range';'dldata_LELoIncCsAbs_mean';'dldata_LELoIncCsAbs_median'; 'dldata_LELoIncCsAbs_std'}),{dldata_LELoIncCsAbs_min; dldata_LELoIncCsAbs_max; dldata_LELoIncCsAbs_range; stripe_LELoIncCsAbs_range; dldata_LELoIncCsAbs_mean; dldata_LELoIncCsAbs_median; dldata_LELoIncCsAbs_std});
writetable(tabdlLELoIncCsAbs,'tabdlLELoIncCsUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the LoIncCs CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig36 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcLoIncCsMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('Average CO2 Emissions in the Low-Income Countries per capita for 1990-2020');
title('Low-Income Cs');

saveas(gcf,'CO2LoIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2LoIncCspcAbs.png')
saveas(gcf,'CO2LoIncCspcAbs.epsc')

CO2LoIncCspcAbs = imread('CO2LoIncCspcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig37 = figure
plot(ticksCO2,data_CO2pcLoIncCsMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average low-income countries CO2 emissions pc, in metric tons')
title('Average Low-Income Countries CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcLoIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcLoIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcLoIncCsMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig38 = figure
plot(ticksdlCO2,dldata_CO2pcLoIncCsMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of average low-income countries CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of Average Low-Income Countries CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcLoIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcLoIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcLoIncCsMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig39 = figure
histogram(data_CO2pcLoIncCsMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average Low-Income Countries CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcLoIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcLoIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcLoIncCsMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig40 = figure
histogram(dldata_CO2pcLoIncCsMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of Average Low-Income Countries CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcLoIncCsMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcLoIncCsMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcLoIncCsMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcLoIncCsMetricTonsAbs_min = min(data_CO2pcLoIncCsMetricTons)
data_CO2pcLoIncCsMetricTonsAbs_max = max(data_CO2pcLoIncCsMetricTons)
data_CO2pcLoIncCsMetricTonsAbs_range = data_CO2pcLoIncCsMetricTonsAbs_max - data_CO2pcLoIncCsMetricTonsAbs_min
stripe_CO2pcLoIncCsMetricTonsAbs_range = data_CO2pcLoIncCsMetricTonsAbs_range/16
data_CO2pcLoIncCsMetricTonsAbs_mean = mean(data_CO2pcLoIncCsMetricTons)
data_CO2pcLoIncCsMetricTonsAbs_median = median(data_CO2pcLoIncCsMetricTons)
%data_CO2pcLoIncCsMetricTonsAbs_mode = mode(data_CO2pcLoIncCsMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcLoIncCsMetricTonsAbs = table(categorical({'data_CO2pcLoIncCsMetricTonsAbs_min';'data_CO2pcLoIncCsMetricTonsAbs_max';'data_CO2pcLoIncCsMetricTons_range';'stripe_CO2pcLoIncCsMetricTonsAbs_range';'data_CO2pcLoIncCsMetricTonsAbs_mean';'data_CO2pcLoIncCsMetricTonsAbs_median'}),{data_CO2pcLoIncCsMetricTonsAbs_min; data_CO2pcLoIncCsMetricTonsAbs_max; data_CO2pcLoIncCsMetricTonsAbs_range; stripe_CO2pcLoIncCsMetricTonsAbs_range; data_CO2pcLoIncCsMetricTonsAbs_mean; data_CO2pcLoIncCsMetricTonsAbs_median})
writetable(tabCO2pcLoIncCsMetricTonsAbs,'tabCO2pcLoIncCsMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcLoIncCsMetricTonsAbs_min = min(dldata_CO2pcLoIncCsMetricTons);
dldata_CO2pcLoIncCsMetricTonsAbs_max = max(dldata_CO2pcLoIncCsMetricTons);
dldata_CO2pcLoIncCsMetricTonsAbs_range = dldata_CO2pcLoIncCsMetricTonsAbs_max - dldata_CO2pcLoIncCsMetricTonsAbs_min;
dlstripe_CO2pcLoIncCsMetricTonsAbs_range = dldata_CO2pcLoIncCsMetricTonsAbs_range/16;
dldata_CO2pcLoIncCsMetricTonsAbs_mean = mean(dldata_CO2pcLoIncCsMetricTons);
dldata_CO2pcLoIncCsMetricTonsAbs_median = median(dldata_CO2pcLoIncCsMetricTons);
%dldata_CO2pcLoIncCsMetricTonsAbs_mode = mode(dldata_CO2pcLoIncCsMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcLoIncCsMetricTonsAbs_std = std(dldata_CO2pcLoIncCsMetricTons);

tabdlCO2pcLoIncCsMetricTonsAbs = table(categorical({'data_CO2pcLoIncCsMetricTonsAbs_min';'data_CO2pcLoIncCsMetricTonsAbs_max';'data_CO2pcLoIncCsMetricTons_range';'stripe_CO2pcLoIncCsMetricTonsAbs_range';'data_CO2pcLoIncCsMetricTonsAbs_mean';'data_CO2pcLoIncCsMetricTonsAbs_median'; 'dldata_CO2pcLoIncCsMetricTonsAbs_std'}),{data_CO2pcLoIncCsMetricTonsAbs_min; data_CO2pcLoIncCsMetricTonsAbs_max; data_CO2pcLoIncCsMetricTonsAbs_range; stripe_CO2pcLoIncCsMetricTonsAbs_range; data_CO2pcLoIncCsMetricTonsAbs_mean; data_CO2pcLoIncCsMetricTonsAbs_median; dldata_CO2pcLoIncCsMetricTonsAbs_std})
writetable(tabdlCO2pcLoIncCsMetricTonsAbs,'tabdlCO2pcLoIncCsMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the LoIncCs Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig41 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcLoIncCsDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('Average Low-Income Countries Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('Low-Income Cs');

saveas(gcf,'GreenProspDefLEPPPUSD2017LoIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017LoIncCspcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017LoIncCspcAbs.epsc')

CO2LoIncCspcAbs = imread('CO2LoIncCspcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig42 = figure
plot(ticksGreenProspLE,data_GreenProsppcLoIncCsDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('average low-income countries greening prosperity ratio pc (LE pc / CO2 pc)')
title('Average Low-Income Countries Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017LoIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017LoIncCspcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017LoIncCspcAbs.epsc')


%% Plot - growth rates

fig43 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcLoIncCsDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of average low-income countries greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of Average Low-Income Countries Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017LoIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017LoIncCspcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017LoIncCspcAbs.epsc')


%% Histogram - absolute level

fig44 = figure
histogram(data_GreenProsppcLoIncCsDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Average Low-Income Countries Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017LoIncCspcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017LoIncCspcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017LoIncCspcAbs.epsc')

%% Histogram - growth rates

fig45 = figure
histogram(dldata_GreenProsppcLoIncCsDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of Average Low-Income Countries Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017LoIncCsAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017LoIncCsAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017LoIncCsAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcLoIncCsDefByLEAbs_min = min(data_GreenProsppcLoIncCsDefByLE);
data_GreenProsppcLoIncCsDefByLEAbs_max = max(data_GreenProsppcLoIncCsDefByLE);
data_GreenProsppcLoIncCsDefByLEAbs_range = data_GreenProsppcLoIncCsDefByLEAbs_max - data_GreenProsppcLoIncCsDefByLEAbs_min;
stripe_GreenProsppcLoIncCsDefByLEAbs_range = data_GreenProsppcLoIncCsDefByLEAbs_range/16;
data_GreenProsppcLoIncCsDefByLEAbs_mean = mean(data_GreenProsppcLoIncCsDefByLE);
data_GreenProsppcLoIncCsDefByLEAbs_median = median(data_GreenProsppcLoIncCsDefByLE);
%data_GreenProsppcLoIncCsDefByLEAbs_mode = mode(data_GreenProsppcLoIncCsDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcLoIncCsDefByLEAbs_std = std(data_GreenProsppcLoIncCsDefByLE);

tabGreenProsppcLoIncCsDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcLoIncCsDefByLEAbs_min';'data_GreenProsppcLoIncCsDefByLEAbs_max';'data_GreenProsppcLoIncCsDefByLE_range';'stripe_GreenProsppcLoIncCsDefByLEAbs_range';'data_GreenProsppcLoIncCsDefByLEAbs_mean';'data_GreenProsppcLoIncCsDefByLEAbs_median'; 'data_GreenProsppcLoIncCsDefByLEAbs_std'}),{data_GreenProsppcLoIncCsDefByLEAbs_min; data_GreenProsppcLoIncCsDefByLEAbs_max; data_GreenProsppcLoIncCsDefByLEAbs_range; stripe_GreenProsppcLoIncCsDefByLEAbs_range; data_GreenProsppcLoIncCsDefByLEAbs_mean; data_GreenProsppcLoIncCsDefByLEAbs_median; data_GreenProsppcLoIncCsDefByLEAbs_std});
writetable(tabGreenProsppcLoIncCsDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcLoIncCsDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcLoIncCsDefByLEAbs_min = min(dldata_GreenProsppcLoIncCsDefByLE);
dldata_GreenProsppcLoIncCsDefByLEAbs_max = max(dldata_GreenProsppcLoIncCsDefByLE);
dldata_GreenProsppcLoIncCsDefByLEAbs_range = dldata_GreenProsppcLoIncCsDefByLEAbs_max - dldata_GreenProsppcLoIncCsDefByLEAbs_min;
dlstripe_GreenProsppcLoIncCsDefByLEAbs_range = dldata_GreenProsppcLoIncCsDefByLEAbs_range/16;
dldata_GreenProsppcLoIncCsDefByLEAbs_mean = mean(dldata_GreenProsppcLoIncCsDefByLE);
dldata_GreenProsppcLoIncCsDefByLEAbs_median = median(dldata_GreenProsppcLoIncCsDefByLE);
%dldata_GreenProsppcLoIncCsDefByLEAbs_mode = mode(dldata_GreenProsppcLoIncCsDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcLoIncCsDefByLEAbs_std = std(dldata_GreenProsppcLoIncCsDefByLE);

tabdlGreenProsppcLoIncCsDefByLEAbs = table(categorical({'dldata_GreenProsppcLoIncCsDefByLEAbs_min';'dldata_GreenProsppcLoIncCsDefByLEAbs_max';'dldata_GreenProsppcLoIncCsDefByLE_range';'dlstripe_GreenProsppcLoIncCsDefByLEAbs_range';'dldata_GreenProsppcLoIncCsDefByLEAbs_mean'; 'dldata_GreenProsppcLoIncCsDefByLEAbs_median';'dldata_GreenProsppcLoIncCsDefByLEAbs_std'}),{dldata_GreenProsppcLoIncCsDefByLEAbs_min; dldata_GreenProsppcLoIncCsDefByLEAbs_max; dldata_GreenProsppcLoIncCsDefByLEAbs_range; dlstripe_GreenProsppcLoIncCsDefByLEAbs_range; dldata_GreenProsppcLoIncCsDefByLEAbs_mean; dldata_GreenProsppcLoIncCsDefByLEAbs_median; dldata_GreenProsppcLoIncCsDefByLEAbs_std});
writetable(tabdlGreenProsppcLoIncCsDefByLEAbs ,'tabdlGreenProsppcLoIncCsDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% United States - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEUS = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI256:BM256');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEUS = log(data_LEUS);
dldata_LEUS = diff(ldata_LEUS)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcUSMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI256:BM256');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcUSMetricTons = log(data_CO2pcUSMetricTons);
dldata_CO2pcUSMetricTons = diff(ldata_CO2pcUSMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcUSDefByLE = data_LEUS ./ data_CO2pcUSMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcUSDefByLE = log(data_GreenProsppcUSDefByLE);
dldata_GreenProsppcUSDefByLE = diff(ldata_GreenProsppcUSDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the US LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig46 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEUS)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('US LE per capita in PPP International USD of 2017 for 1990-1990');
title('US');

saveas(gcf,'LEUSpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEUSpcAbs.png')
saveas(gcf,'LEUSpcAbs.epsc')

LEUSpcDev = imread('LEUSpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig47 = figure
plot(ticksLE,data_LEUS,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('US LE per capita in PPP international USD of 2017')
title('US LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEUSAbsSince1990Annual.png')
saveas(gcf,'Plot_LEUSAbsSince1990Annual.epsc')


%% Plot - growth rates

fig48 = figure
plot(ticksdlLE,dldata_LEUS,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of US LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of US LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEUSAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEUSAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig49 = figure
histogram(data_LEUS,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('US LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEUSAbsSince1990Annual.png')
saveas(gcf,'Hist_LEUSAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig50 = figure
histogram(dldata_LEUS,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of US LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEUSAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEUSAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEUSAbs_min = min(data_LEUS)
data_LEUSAbs_max = max(data_LEUS)
data_LEUSAbs_range = data_LEUSAbs_max - data_LEUSAbs_min
stripe_LEUSAbs_range = data_LEUSAbs_range/16
data_LEUSAbs_mean = mean(data_LEUS)
data_LEUSAbs_median = median(data_LEUS)
%data_LEUSAbs_mode = mode(data_LEUS,'all') %AM230708 Sth's wrong about the mode command?!

tabLEUSAbs = table(categorical({'data_LEUSAbs_min';'data_LEUSAbs_max';'data_LEUSAbs_range';'stripe_LEUSAbs_range';'data_LEUSAbs_mean';'data_LEUSAbs_median'}),{data_LEUSAbs_min; data_LEUSAbs_max; data_LEUSAbs_range; stripe_LEUSAbs_range; data_LEUSAbs_mean; data_LEUSAbs_median})
writetable(tabLEUSAbs,'tabLEUSUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEUSAbs_min = min(dldata_LEUS);
dldata_LEUSAbs_max = max(dldata_LEUS);
dldata_LEUSAbs_range = dldata_LEUSAbs_max - dldata_LEUSAbs_min;
dlstripe_LEUSAbs_range = dldata_LEUSAbs_range/16;
dldata_LEUSAbs_mean = mean(dldata_LEUS);
dldata_LEUSAbs_median = median(dldata_LEUS);
%dldata_LEUSAbs_mode = mode(dldata_LEUS,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEUSAbs_std = std(dldata_LEUS);

tabdlLEUSAbs = table(categorical({'dldata_LEUSAbs_min';'dldata_LEUSAbs_max';'dldata_LEUSAbs_range';'dlstripe_LEUSAbs_range';'dldata_LEUSAbs_mean';'dldata_LEUSAbs_median'; 'dldata_LEUSAbs_std'}),{dldata_LEUSAbs_min; dldata_LEUSAbs_max; dldata_LEUSAbs_range; stripe_LEUSAbs_range; dldata_LEUSAbs_mean; dldata_LEUSAbs_median; dldata_LEUSAbs_std});
writetable(tabdlLEUSAbs,'tabdlLEUSUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the US CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig51 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcUSMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in the US per capita for 1990-2020');
title('US');

saveas(gcf,'CO2USpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2USpcAbs.png')
saveas(gcf,'CO2USpcAbs.epsc')

CO2USpcAbs = imread('CO2USpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig52 = figure
plot(ticksCO2,data_CO2pcUSMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('US CO2 emissions pc, in metric tons')
title('US CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcUSMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcUSMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig53 = figure
plot(ticksdlCO2,dldata_CO2pcUSMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of US CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of US CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcUSMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcUSMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig54 = figure
histogram(data_CO2pcUSMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('US CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcUSMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcUSMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig55 = figure
histogram(dldata_CO2pcUSMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of US CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcUSMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcUSMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcUSMetricTonsAbs_min = min(data_CO2pcUSMetricTons)
data_CO2pcUSMetricTonsAbs_max = max(data_CO2pcUSMetricTons)
data_CO2pcUSMetricTonsAbs_range = data_CO2pcUSMetricTonsAbs_max - data_CO2pcUSMetricTonsAbs_min
stripe_CO2pcUSMetricTonsAbs_range = data_CO2pcUSMetricTonsAbs_range/16
data_CO2pcUSMetricTonsAbs_mean = mean(data_CO2pcUSMetricTons)
data_CO2pcUSMetricTonsAbs_median = median(data_CO2pcUSMetricTons)
%data_CO2pcUSMetricTonsAbs_mode = mode(data_CO2pcUSMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcUSMetricTonsAbs = table(categorical({'data_CO2pcUSMetricTonsAbs_min';'data_CO2pcUSMetricTonsAbs_max';'data_CO2pcUSMetricTons_range';'stripe_CO2pcUSMetricTonsAbs_range';'data_CO2pcUSMetricTonsAbs_mean';'data_CO2pcUSMetricTonsAbs_median'}),{data_CO2pcUSMetricTonsAbs_min; data_CO2pcUSMetricTonsAbs_max; data_CO2pcUSMetricTonsAbs_range; stripe_CO2pcUSMetricTonsAbs_range; data_CO2pcUSMetricTonsAbs_mean; data_CO2pcUSMetricTonsAbs_median})
writetable(tabCO2pcUSMetricTonsAbs,'tabCO2pcUSMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcUSMetricTonsAbs_min = min(dldata_CO2pcUSMetricTons);
dldata_CO2pcUSMetricTonsAbs_max = max(dldata_CO2pcUSMetricTons);
dldata_CO2pcUSMetricTonsAbs_range = dldata_CO2pcUSMetricTonsAbs_max - dldata_CO2pcUSMetricTonsAbs_min;
dlstripe_CO2pcUSMetricTonsAbs_range = dldata_CO2pcUSMetricTonsAbs_range/16;
dldata_CO2pcUSMetricTonsAbs_mean = mean(dldata_CO2pcUSMetricTons);
dldata_CO2pcUSMetricTonsAbs_median = median(dldata_CO2pcUSMetricTons);
%dldata_CO2pcUSMetricTonsAbs_mode = mode(dldata_CO2pcUSMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcUSMetricTonsAbs_std = std(dldata_CO2pcUSMetricTons);

tabdlCO2pcUSMetricTonsAbs = table(categorical({'data_CO2pcUSMetricTonsAbs_min';'data_CO2pcUSMetricTonsAbs_max';'data_CO2pcUSMetricTons_range';'stripe_CO2pcUSMetricTonsAbs_range';'data_CO2pcUSMetricTonsAbs_mean';'data_CO2pcUSMetricTonsAbs_median'; 'dldata_CO2pcUSMetricTonsAbs_std'}),{data_CO2pcUSMetricTonsAbs_min; data_CO2pcUSMetricTonsAbs_max; data_CO2pcUSMetricTonsAbs_range; stripe_CO2pcUSMetricTonsAbs_range; data_CO2pcUSMetricTonsAbs_mean; data_CO2pcUSMetricTonsAbs_median; dldata_CO2pcUSMetricTonsAbs_std})
writetable(tabdlCO2pcUSMetricTonsAbs,'tabdlCO2pcUSMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the US Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig56 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcUSDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('US Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('US');

saveas(gcf,'GreenProspDefLEPPPUSD2017USpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017USpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017USpcAbs.epsc')

CO2USpcAbs = imread('CO2USpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig57 = figure
plot(ticksGreenProspLE,data_GreenProsppcUSDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('US greening prosperity ratio pc (LE pc / CO2 pc)')
title('US Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017USpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017USpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017USpcAbs.epsc')

%% Plot - growth rates

fig58 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcUSDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of US greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of US Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017USpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017USpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017USpcAbs.epsc')


%% Histogram - absolute level

fig59 = figure
histogram(data_GreenProsppcUSDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('US Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017USpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017USpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017USpcAbs.epsc')

%% Histogram - growth rates

fig60 = figure
histogram(dldata_GreenProsppcUSDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of US Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017USAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017USAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017USAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcUSDefByLEAbs_min = min(data_GreenProsppcUSDefByLE);
data_GreenProsppcUSDefByLEAbs_max = max(data_GreenProsppcUSDefByLE);
data_GreenProsppcUSDefByLEAbs_range = data_GreenProsppcUSDefByLEAbs_max - data_GreenProsppcUSDefByLEAbs_min;
stripe_GreenProsppcUSDefByLEAbs_range = data_GreenProsppcUSDefByLEAbs_range/16;
data_GreenProsppcUSDefByLEAbs_mean = mean(data_GreenProsppcUSDefByLE);
data_GreenProsppcUSDefByLEAbs_median = median(data_GreenProsppcUSDefByLE);
%data_GreenProsppcUSDefByLEAbs_mode = mode(data_GreenProsppcUSDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcUSDefByLEAbs_std = std(data_GreenProsppcUSDefByLE);

tabGreenProsppcUSDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcUSDefByLEAbs_min';'data_GreenProsppcUSDefByLEAbs_max';'data_GreenProsppcUSDefByLE_range';'stripe_GreenProsppcUSDefByLEAbs_range';'data_GreenProsppcUSDefByLEAbs_mean';'data_GreenProsppcUSDefByLEAbs_median'; 'data_GreenProsppcUSDefByLEAbs_std'}),{data_GreenProsppcUSDefByLEAbs_min; data_GreenProsppcUSDefByLEAbs_max; data_GreenProsppcUSDefByLEAbs_range; stripe_GreenProsppcUSDefByLEAbs_range; data_GreenProsppcUSDefByLEAbs_mean; data_GreenProsppcUSDefByLEAbs_median; data_GreenProsppcUSDefByLEAbs_std});
writetable(tabGreenProsppcUSDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcUSDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcUSDefByLEAbs_min = min(dldata_GreenProsppcUSDefByLE);
dldata_GreenProsppcUSDefByLEAbs_max = max(dldata_GreenProsppcUSDefByLE);
dldata_GreenProsppcUSDefByLEAbs_range = dldata_GreenProsppcUSDefByLEAbs_max - dldata_GreenProsppcUSDefByLEAbs_min;
dlstripe_GreenProsppcUSDefByLEAbs_range = dldata_GreenProsppcUSDefByLEAbs_range/16;
dldata_GreenProsppcUSDefByLEAbs_mean = mean(dldata_GreenProsppcUSDefByLE);
dldata_GreenProsppcUSDefByLEAbs_median = median(dldata_GreenProsppcUSDefByLE);
%dldata_GreenProsppcUSDefByLEAbs_mode = mode(dldata_GreenProsppcUSDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcUSDefByLEAbs_std = std(dldata_GreenProsppcUSDefByLE);

tabdlGreenProsppcUSDefByLEAbs = table(categorical({'dldata_GreenProsppcUSDefByLEAbs_min';'dldata_GreenProsppcUSDefByLEAbs_max';'dldata_GreenProsppcUSDefByLE_range';'dlstripe_GreenProsppcUSDefByLEAbs_range';'dldata_GreenProsppcUSDefByLEAbs_mean'; 'dldata_GreenProsppcUSDefByLEAbs_median';'dldata_GreenProsppcUSDefByLEAbs_std'}),{dldata_GreenProsppcUSDefByLEAbs_min; dldata_GreenProsppcUSDefByLEAbs_max; dldata_GreenProsppcUSDefByLEAbs_range; dlstripe_GreenProsppcUSDefByLEAbs_range; dldata_GreenProsppcUSDefByLEAbs_mean; dldata_GreenProsppcUSDefByLEAbs_median; dldata_GreenProsppcUSDefByLEAbs_std});
writetable(tabdlGreenProsppcUSDefByLEAbs ,'tabdlGreenProsppcUSDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Mozambique - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEMOZ = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI170:BM170');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEMOZ = log(data_LEMOZ);
dldata_LEMOZ = diff(ldata_LEMOZ)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcMOZMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI170:BM170');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcMOZMetricTons = log(data_CO2pcMOZMetricTons);
dldata_CO2pcMOZMetricTons = diff(ldata_CO2pcMOZMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcMOZDefByLE = data_LEMOZ ./ data_CO2pcMOZMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcMOZDefByLE = log(data_GreenProsppcMOZDefByLE);
dldata_GreenProsppcMOZDefByLE = diff(ldata_GreenProsppcMOZDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the MOZ LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig61 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEMOZ)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('Mozambique LE per capita in PPP International USD of 2017 for 1990-1990');
title('Mozambique');

saveas(gcf,'LEMOZpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEMOZpcAbs.png')
saveas(gcf,'LEMOZpcAbs.epsc')

LEMOZpcDev = imread('LEMOZpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig62 = figure
plot(ticksLE,data_LEMOZ,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Mozambique LE per capita in PPP international USD of 2017')
title('Mozambique LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEMOZAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEMOZAbsSince1990Annual.png')
saveas(gcf,'Plot_LEMOZAbsSince1990Annual.epsc')


%% Plot - growth rates

fig63 = figure
plot(ticksdlLE,dldata_LEMOZ,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of Mozambique LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of Mozambique LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEMOZAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEMOZAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEMOZAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig64 = figure
histogram(data_LEMOZ,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Mozambique LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEMOZAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEMOZAbsSince1990Annual.png')
saveas(gcf,'Hist_LEMOZAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig65 = figure
histogram(dldata_LEMOZ,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of Mozambique LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEMOZAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEMOZAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEMOZAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEMOZAbs_min = min(data_LEMOZ)
data_LEMOZAbs_max = max(data_LEMOZ)
data_LEMOZAbs_range = data_LEMOZAbs_max - data_LEMOZAbs_min
stripe_LEMOZAbs_range = data_LEMOZAbs_range/16
data_LEMOZAbs_mean = mean(data_LEMOZ)
data_LEMOZAbs_median = median(data_LEMOZ)
%data_LEMOZAbs_mode = mode(data_LEMOZ,'all') %AM230708 Sth's wrong about the mode command?!

tabLEMOZAbs = table(categorical({'data_LEMOZAbs_min';'data_LEMOZAbs_max';'data_LEMOZAbs_range';'stripe_LEMOZAbs_range';'data_LEMOZAbs_mean';'data_LEMOZAbs_median'}),{data_LEMOZAbs_min; data_LEMOZAbs_max; data_LEMOZAbs_range; stripe_LEMOZAbs_range; data_LEMOZAbs_mean; data_LEMOZAbs_median})
writetable(tabLEMOZAbs,'tabLEMOZUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEMOZAbs_min = min(dldata_LEMOZ);
dldata_LEMOZAbs_max = max(dldata_LEMOZ);
dldata_LEMOZAbs_range = dldata_LEMOZAbs_max - dldata_LEMOZAbs_min;
dlstripe_LEMOZAbs_range = dldata_LEMOZAbs_range/16;
dldata_LEMOZAbs_mean = mean(dldata_LEMOZ);
dldata_LEMOZAbs_median = median(dldata_LEMOZ);
%dldata_LEMOZAbs_mode = mode(dldata_LEMOZ,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEMOZAbs_std = std(dldata_LEMOZ);

tabdlLEMOZAbs = table(categorical({'dldata_LEMOZAbs_min';'dldata_LEMOZAbs_max';'dldata_LEMOZAbs_range';'dlstripe_LEMOZAbs_range';'dldata_LEMOZAbs_mean';'dldata_LEMOZAbs_median'; 'dldata_LEMOZAbs_std'}),{dldata_LEMOZAbs_min; dldata_LEMOZAbs_max; dldata_LEMOZAbs_range; stripe_LEMOZAbs_range; dldata_LEMOZAbs_mean; dldata_LEMOZAbs_median; dldata_LEMOZAbs_std});
writetable(tabdlLEMOZAbs,'tabdlLEMOZUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the MOZ CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig66 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcMOZMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in Mozambique per capita for 1990-2020');
title('Mozambique');

saveas(gcf,'CO2MOZpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2MOZpcAbs.png')
saveas(gcf,'CO2MOZpcAbs.epsc')

CO2MOZpcAbs = imread('CO2MOZpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig67 = figure
plot(ticksCO2,data_CO2pcMOZMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Mozambique CO2 emissions pc, in metric tons')
title('Mozambique CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcMOZMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcMOZMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcMOZMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig68 = figure
plot(ticksdlCO2,dldata_CO2pcMOZMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of Mozambique CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of Mozambique CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcMOZMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcMOZMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcMOZMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig69 = figure
histogram(data_CO2pcMOZMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Mozambique CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcMOZMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcMOZMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcMOZMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig70 = figure
histogram(dldata_CO2pcMOZMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of Mozambique CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcMOZMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcMOZMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcMOZMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcMOZMetricTonsAbs_min = min(data_CO2pcMOZMetricTons)
data_CO2pcMOZMetricTonsAbs_max = max(data_CO2pcMOZMetricTons)
data_CO2pcMOZMetricTonsAbs_range = data_CO2pcMOZMetricTonsAbs_max - data_CO2pcMOZMetricTonsAbs_min
stripe_CO2pcMOZMetricTonsAbs_range = data_CO2pcMOZMetricTonsAbs_range/16
data_CO2pcMOZMetricTonsAbs_mean = mean(data_CO2pcMOZMetricTons)
data_CO2pcMOZMetricTonsAbs_median = median(data_CO2pcMOZMetricTons)
%data_CO2pcMOZMetricTonsAbs_mode = mode(data_CO2pcMOZMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcMOZMetricTonsAbs = table(categorical({'data_CO2pcMOZMetricTonsAbs_min';'data_CO2pcMOZMetricTonsAbs_max';'data_CO2pcMOZMetricTons_range';'stripe_CO2pcMOZMetricTonsAbs_range';'data_CO2pcMOZMetricTonsAbs_mean';'data_CO2pcMOZMetricTonsAbs_median'}),{data_CO2pcMOZMetricTonsAbs_min; data_CO2pcMOZMetricTonsAbs_max; data_CO2pcMOZMetricTonsAbs_range; stripe_CO2pcMOZMetricTonsAbs_range; data_CO2pcMOZMetricTonsAbs_mean; data_CO2pcMOZMetricTonsAbs_median})
writetable(tabCO2pcMOZMetricTonsAbs,'tabCO2pcMOZMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcMOZMetricTonsAbs_min = min(dldata_CO2pcMOZMetricTons);
dldata_CO2pcMOZMetricTonsAbs_max = max(dldata_CO2pcMOZMetricTons);
dldata_CO2pcMOZMetricTonsAbs_range = dldata_CO2pcMOZMetricTonsAbs_max - dldata_CO2pcMOZMetricTonsAbs_min;
dlstripe_CO2pcMOZMetricTonsAbs_range = dldata_CO2pcMOZMetricTonsAbs_range/16;
dldata_CO2pcMOZMetricTonsAbs_mean = mean(dldata_CO2pcMOZMetricTons);
dldata_CO2pcMOZMetricTonsAbs_median = median(dldata_CO2pcMOZMetricTons);
%dldata_CO2pcMOZMetricTonsAbs_mode = mode(dldata_CO2pcMOZMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcMOZMetricTonsAbs_std = std(dldata_CO2pcMOZMetricTons);

tabdlCO2pcMOZMetricTonsAbs = table(categorical({'data_CO2pcMOZMetricTonsAbs_min';'data_CO2pcMOZMetricTonsAbs_max';'data_CO2pcMOZMetricTons_range';'stripe_CO2pcMOZMetricTonsAbs_range';'data_CO2pcMOZMetricTonsAbs_mean';'data_CO2pcMOZMetricTonsAbs_median'; 'dldata_CO2pcMOZMetricTonsAbs_std'}),{data_CO2pcMOZMetricTonsAbs_min; data_CO2pcMOZMetricTonsAbs_max; data_CO2pcMOZMetricTonsAbs_range; stripe_CO2pcMOZMetricTonsAbs_range; data_CO2pcMOZMetricTonsAbs_mean; data_CO2pcMOZMetricTonsAbs_median; dldata_CO2pcMOZMetricTonsAbs_std})
writetable(tabdlCO2pcMOZMetricTonsAbs,'tabdlCO2pcMOZMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the MOZ Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig71 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcMOZDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('Mozambique Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('Mozambique');

saveas(gcf,'GreenProspDefLEPPPUSD2017MOZpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017MOZpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017MOZpcAbs.epsc')

CO2MOZpcAbs = imread('CO2MOZpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig72 = figure
plot(ticksGreenProspLE,data_GreenProsppcMOZDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Mozambique greening prosperity ratio pc (LE pc / CO2 pc)')
title('Mozambique Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017MOZpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017MOZpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017MOZpcAbs.epsc')

%% Plot - growth rates

fig73 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcMOZDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of Mozambique greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of Mozambique Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017MOZpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017MOZpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017MOZpcAbs.epsc')


%% Histogram - absolute level

fig74 = figure
histogram(data_GreenProsppcMOZDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Mozambique Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017MOZpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017MOZpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017MOZpcAbs.epsc')

%% Histogram - growth rates

fig75 = figure
histogram(dldata_GreenProsppcMOZDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of Mozambique Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017MOZAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017MOZAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017MOZAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcMOZDefByLEAbs_min = min(data_GreenProsppcMOZDefByLE);
data_GreenProsppcMOZDefByLEAbs_max = max(data_GreenProsppcMOZDefByLE);
data_GreenProsppcMOZDefByLEAbs_range = data_GreenProsppcMOZDefByLEAbs_max - data_GreenProsppcMOZDefByLEAbs_min;
stripe_GreenProsppcMOZDefByLEAbs_range = data_GreenProsppcMOZDefByLEAbs_range/16;
data_GreenProsppcMOZDefByLEAbs_mean = mean(data_GreenProsppcMOZDefByLE);
data_GreenProsppcMOZDefByLEAbs_median = median(data_GreenProsppcMOZDefByLE);
%data_GreenProsppcMOZDefByLEAbs_mode = mode(data_GreenProsppcMOZDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcMOZDefByLEAbs_std = std(data_GreenProsppcMOZDefByLE);

tabGreenProsppcMOZDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcMOZDefByLEAbs_min';'data_GreenProsppcMOZDefByLEAbs_max';'data_GreenProsppcMOZDefByLE_range';'stripe_GreenProsppcMOZDefByLEAbs_range';'data_GreenProsppcMOZDefByLEAbs_mean';'data_GreenProsppcMOZDefByLEAbs_median'; 'data_GreenProsppcMOZDefByLEAbs_std'}),{data_GreenProsppcMOZDefByLEAbs_min; data_GreenProsppcMOZDefByLEAbs_max; data_GreenProsppcMOZDefByLEAbs_range; stripe_GreenProsppcMOZDefByLEAbs_range; data_GreenProsppcMOZDefByLEAbs_mean; data_GreenProsppcMOZDefByLEAbs_median; data_GreenProsppcMOZDefByLEAbs_std});
writetable(tabGreenProsppcMOZDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcMOZDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcMOZDefByLEAbs_min = min(dldata_GreenProsppcMOZDefByLE);
dldata_GreenProsppcMOZDefByLEAbs_max = max(dldata_GreenProsppcMOZDefByLE);
dldata_GreenProsppcMOZDefByLEAbs_range = dldata_GreenProsppcMOZDefByLEAbs_max - dldata_GreenProsppcMOZDefByLEAbs_min;
dlstripe_GreenProsppcMOZDefByLEAbs_range = dldata_GreenProsppcMOZDefByLEAbs_range/16;
dldata_GreenProsppcMOZDefByLEAbs_mean = mean(dldata_GreenProsppcMOZDefByLE);
dldata_GreenProsppcMOZDefByLEAbs_median = median(dldata_GreenProsppcMOZDefByLE);
%dldata_GreenProsppcMOZDefByLEAbs_mode = mode(dldata_GreenProsppcMOZDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcMOZDefByLEAbs_std = std(dldata_GreenProsppcMOZDefByLE);

tabdlGreenProsppcMOZDefByLEAbs = table(categorical({'dldata_GreenProsppcMOZDefByLEAbs_min';'dldata_GreenProsppcMOZDefByLEAbs_max';'dldata_GreenProsppcMOZDefByLE_range';'dlstripe_GreenProsppcMOZDefByLEAbs_range';'dldata_GreenProsppcMOZDefByLEAbs_mean'; 'dldata_GreenProsppcMOZDefByLEAbs_median';'dldata_GreenProsppcMOZDefByLEAbs_std'}),{dldata_GreenProsppcMOZDefByLEAbs_min; dldata_GreenProsppcMOZDefByLEAbs_max; dldata_GreenProsppcMOZDefByLEAbs_range; dlstripe_GreenProsppcMOZDefByLEAbs_range; dldata_GreenProsppcMOZDefByLEAbs_mean; dldata_GreenProsppcMOZDefByLEAbs_median; dldata_GreenProsppcMOZDefByLEAbs_std});
writetable(tabdlGreenProsppcMOZDefByLEAbs ,'tabdlGreenProsppcMOZDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% United Kingdom - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEUK = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI86:BM86');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEUK = log(data_LEUK);
dldata_LEUK = diff(ldata_LEUK)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcUKMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI86:BM86');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcUKMetricTons = log(data_CO2pcUKMetricTons);
dldata_CO2pcUKMetricTons = diff(ldata_CO2pcUKMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcUKDefByLE = data_LEUK ./ data_CO2pcUKMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcUKDefByLE = log(data_GreenProsppcUKDefByLE);
dldata_GreenProsppcUKDefByLE = diff(ldata_GreenProsppcUKDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the UK LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig76 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEUK)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('UK LE per capita in PPP International USD of 2017 for 1990-1990');
title('UK');

saveas(gcf,'LEUKpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEUKpcAbs.png')
saveas(gcf,'LEUKpcAbs.epsc')

LEUKpcDev = imread('LEUKpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig77 = figure
plot(ticksLE,data_LEUK,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('UK LE per capita in PPP international USD of 2017')
title('UK LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEUKAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEUKAbsSince1990Annual.png')
saveas(gcf,'Plot_LEUKAbsSince1990Annual.epsc')


%% Plot - growth rates

fig78 = figure
plot(ticksdlLE,dldata_LEUK,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of UK LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of UK LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEUKAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEUKAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEUKAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig79 = figure
histogram(data_LEUK,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('UK LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEUKAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEUKAbsSince1990Annual.png')
saveas(gcf,'Hist_LEUKAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig80 = figure
histogram(dldata_LEUK,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of UK LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEUKAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEUKAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEUKAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEUKAbs_min = min(data_LEUK)
data_LEUKAbs_max = max(data_LEUK)
data_LEUKAbs_range = data_LEUKAbs_max - data_LEUKAbs_min
stripe_LEUKAbs_range = data_LEUKAbs_range/16
data_LEUKAbs_mean = mean(data_LEUK)
data_LEUKAbs_median = median(data_LEUK)
%data_LEUKAbs_mode = mode(data_LEUK,'all') %AM230708 Sth's wrong about the mode command?!

tabLEUKAbs = table(categorical({'data_LEUKAbs_min';'data_LEUKAbs_max';'data_LEUKAbs_range';'stripe_LEUKAbs_range';'data_LEUKAbs_mean';'data_LEUKAbs_median'}),{data_LEUKAbs_min; data_LEUKAbs_max; data_LEUKAbs_range; stripe_LEUKAbs_range; data_LEUKAbs_mean; data_LEUKAbs_median})
writetable(tabLEUKAbs,'tabLEUKUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEUKAbs_min = min(dldata_LEUK);
dldata_LEUKAbs_max = max(dldata_LEUK);
dldata_LEUKAbs_range = dldata_LEUKAbs_max - dldata_LEUKAbs_min;
dlstripe_LEUKAbs_range = dldata_LEUKAbs_range/16;
dldata_LEUKAbs_mean = mean(dldata_LEUK);
dldata_LEUKAbs_median = median(dldata_LEUK);
%dldata_LEUKAbs_mode = mode(dldata_LEUK,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEUKAbs_std = std(dldata_LEUK);

tabdlLEUKAbs = table(categorical({'dldata_LEUKAbs_min';'dldata_LEUKAbs_max';'dldata_LEUKAbs_range';'dlstripe_LEUKAbs_range';'dldata_LEUKAbs_mean';'dldata_LEUKAbs_median'; 'dldata_LEUKAbs_std'}),{dldata_LEUKAbs_min; dldata_LEUKAbs_max; dldata_LEUKAbs_range; stripe_LEUKAbs_range; dldata_LEUKAbs_mean; dldata_LEUKAbs_median; dldata_LEUKAbs_std});
writetable(tabdlLEUKAbs,'tabdlLEUKUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the UK CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig81 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcUKMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in the UK per capita for 1990-2020');
title('UK');

saveas(gcf,'CO2UKpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2UKpcAbs.png')
saveas(gcf,'CO2UKpcAbs.epsc')

CO2UKpcAbs = imread('CO2UKpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig82 = figure
plot(ticksCO2,data_CO2pcUKMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('UK CO2 emissions pc, in metric tons')
title('UK CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcUKMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcUKMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcUKMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig83 = figure
plot(ticksdlCO2,dldata_CO2pcUKMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of UK CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of UK CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcUKMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcUKMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcUKMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig84 = figure
histogram(data_CO2pcUKMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('UK CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcUKMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcUKMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcUKMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig85 = figure
histogram(dldata_CO2pcUKMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of UK CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcUKMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcUKMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcUKMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcUKMetricTonsAbs_min = min(data_CO2pcUKMetricTons)
data_CO2pcUKMetricTonsAbs_max = max(data_CO2pcUKMetricTons)
data_CO2pcUKMetricTonsAbs_range = data_CO2pcUKMetricTonsAbs_max - data_CO2pcUKMetricTonsAbs_min
stripe_CO2pcUKMetricTonsAbs_range = data_CO2pcUKMetricTonsAbs_range/16
data_CO2pcUKMetricTonsAbs_mean = mean(data_CO2pcUKMetricTons)
data_CO2pcUKMetricTonsAbs_median = median(data_CO2pcUKMetricTons)
%data_CO2pcUKMetricTonsAbs_mode = mode(data_CO2pcUKMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcUKMetricTonsAbs = table(categorical({'data_CO2pcUKMetricTonsAbs_min';'data_CO2pcUKMetricTonsAbs_max';'data_CO2pcUKMetricTons_range';'stripe_CO2pcUKMetricTonsAbs_range';'data_CO2pcUKMetricTonsAbs_mean';'data_CO2pcUKMetricTonsAbs_median'}),{data_CO2pcUKMetricTonsAbs_min; data_CO2pcUKMetricTonsAbs_max; data_CO2pcUKMetricTonsAbs_range; stripe_CO2pcUKMetricTonsAbs_range; data_CO2pcUKMetricTonsAbs_mean; data_CO2pcUKMetricTonsAbs_median})
writetable(tabCO2pcUKMetricTonsAbs,'tabCO2pcUKMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcUKMetricTonsAbs_min = min(dldata_CO2pcUKMetricTons);
dldata_CO2pcUKMetricTonsAbs_max = max(dldata_CO2pcUKMetricTons);
dldata_CO2pcUKMetricTonsAbs_range = dldata_CO2pcUKMetricTonsAbs_max - dldata_CO2pcUKMetricTonsAbs_min;
dlstripe_CO2pcUKMetricTonsAbs_range = dldata_CO2pcUKMetricTonsAbs_range/16;
dldata_CO2pcUKMetricTonsAbs_mean = mean(dldata_CO2pcUKMetricTons);
dldata_CO2pcUKMetricTonsAbs_median = median(dldata_CO2pcUKMetricTons);
%dldata_CO2pcUKMetricTonsAbs_mode = mode(dldata_CO2pcUKMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcUKMetricTonsAbs_std = std(dldata_CO2pcUKMetricTons);

tabdlCO2pcUKMetricTonsAbs = table(categorical({'data_CO2pcUKMetricTonsAbs_min';'data_CO2pcUKMetricTonsAbs_max';'data_CO2pcUKMetricTons_range';'stripe_CO2pcUKMetricTonsAbs_range';'data_CO2pcUKMetricTonsAbs_mean';'data_CO2pcUKMetricTonsAbs_median'; 'dldata_CO2pcUKMetricTonsAbs_std'}),{data_CO2pcUKMetricTonsAbs_min; data_CO2pcUKMetricTonsAbs_max; data_CO2pcUKMetricTonsAbs_range; stripe_CO2pcUKMetricTonsAbs_range; data_CO2pcUKMetricTonsAbs_mean; data_CO2pcUKMetricTonsAbs_median; dldata_CO2pcUKMetricTonsAbs_std})
writetable(tabdlCO2pcUKMetricTonsAbs,'tabdlCO2pcUKMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the UK Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig86 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcUKDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('UK Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('UK');

saveas(gcf,'GreenProspDefLEPPPUSD2017UKpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017UKpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017UKpcAbs.epsc')

CO2UKpcAbs = imread('CO2UKpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig87 = figure
plot(ticksGreenProspLE,data_GreenProsppcUKDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('UK greening prosperity ratio pc (LE pc / CO2 pc)')
title('UK Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017UKpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017UKpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017UKpcAbs.epsc')

%% Plot - growth rates

fig88 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcUKDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of UK greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of UK Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017UKpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017UKpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017UKpcAbs.epsc')


%% Histogram - absolute level

fig89 = figure
histogram(data_GreenProsppcUKDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('UK Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017UKpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017UKpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017UKpcAbs.epsc')

%% Histogram - growth rates

fig90 = figure
histogram(dldata_GreenProsppcUKDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of UK Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017UKAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017UKAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017UKAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcUKDefByLEAbs_min = min(data_GreenProsppcUKDefByLE);
data_GreenProsppcUKDefByLEAbs_max = max(data_GreenProsppcUKDefByLE);
data_GreenProsppcUKDefByLEAbs_range = data_GreenProsppcUKDefByLEAbs_max - data_GreenProsppcUKDefByLEAbs_min;
stripe_GreenProsppcUKDefByLEAbs_range = data_GreenProsppcUKDefByLEAbs_range/16;
data_GreenProsppcUKDefByLEAbs_mean = mean(data_GreenProsppcUKDefByLE);
data_GreenProsppcUKDefByLEAbs_median = median(data_GreenProsppcUKDefByLE);
%data_GreenProsppcUKDefByLEAbs_mode = mode(data_GreenProsppcUKDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcUKDefByLEAbs_std = std(data_GreenProsppcUKDefByLE);

tabGreenProsppcUKDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcUKDefByLEAbs_min';'data_GreenProsppcUKDefByLEAbs_max';'data_GreenProsppcUKDefByLE_range';'stripe_GreenProsppcUKDefByLEAbs_range';'data_GreenProsppcUKDefByLEAbs_mean';'data_GreenProsppcUKDefByLEAbs_median'; 'data_GreenProsppcUKDefByLEAbs_std'}),{data_GreenProsppcUKDefByLEAbs_min; data_GreenProsppcUKDefByLEAbs_max; data_GreenProsppcUKDefByLEAbs_range; stripe_GreenProsppcUKDefByLEAbs_range; data_GreenProsppcUKDefByLEAbs_mean; data_GreenProsppcUKDefByLEAbs_median; data_GreenProsppcUKDefByLEAbs_std});
writetable(tabGreenProsppcUKDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcUKDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcUKDefByLEAbs_min = min(dldata_GreenProsppcUKDefByLE);
dldata_GreenProsppcUKDefByLEAbs_max = max(dldata_GreenProsppcUKDefByLE);
dldata_GreenProsppcUKDefByLEAbs_range = dldata_GreenProsppcUKDefByLEAbs_max - dldata_GreenProsppcUKDefByLEAbs_min;
dlstripe_GreenProsppcUKDefByLEAbs_range = dldata_GreenProsppcUKDefByLEAbs_range/16;
dldata_GreenProsppcUKDefByLEAbs_mean = mean(dldata_GreenProsppcUKDefByLE);
dldata_GreenProsppcUKDefByLEAbs_median = median(dldata_GreenProsppcUKDefByLE);
%dldata_GreenProsppcUKDefByLEAbs_mode = mode(dldata_GreenProsppcUKDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcUKDefByLEAbs_std = std(dldata_GreenProsppcUKDefByLE);

tabdlGreenProsppcUKDefByLEAbs = table(categorical({'dldata_GreenProsppcUKDefByLEAbs_min';'dldata_GreenProsppcUKDefByLEAbs_max';'dldata_GreenProsppcUKDefByLE_range';'dlstripe_GreenProsppcUKDefByLEAbs_range';'dldata_GreenProsppcUKDefByLEAbs_mean'; 'dldata_GreenProsppcUKDefByLEAbs_median';'dldata_GreenProsppcUKDefByLEAbs_std'}),{dldata_GreenProsppcUKDefByLEAbs_min; dldata_GreenProsppcUKDefByLEAbs_max; dldata_GreenProsppcUKDefByLEAbs_range; dlstripe_GreenProsppcUKDefByLEAbs_range; dldata_GreenProsppcUKDefByLEAbs_mean; dldata_GreenProsppcUKDefByLEAbs_median; dldata_GreenProsppcUKDefByLEAbs_std});
writetable(tabdlGreenProsppcUKDefByLEAbs ,'tabdlGreenProsppcUKDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% China - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LECHN = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI45:BM45');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LECHN = log(data_LECHN);
dldata_LECHN = diff(ldata_LECHN)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcCHNMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI45:BM45');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcCHNMetricTons = log(data_CO2pcCHNMetricTons);
dldata_CO2pcCHNMetricTons = diff(ldata_CO2pcCHNMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcCHNDefByLE = data_LECHN ./ data_CO2pcCHNMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcCHNDefByLE = log(data_GreenProsppcCHNDefByLE);
dldata_GreenProsppcCHNDefByLE = diff(ldata_GreenProsppcCHNDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the CHN LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig91 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LECHN)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('China LE per capita in PPP International USD of 2017 for 1990-1990');
title('China');

saveas(gcf,'LECHNpcAbs.fig') %AM230701 checking online
saveas(gcf,'LECHNpcAbs.png')
saveas(gcf,'LECHNpcAbs.epsc')

LECHNpcDev = imread('LECHNpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig92 = figure
plot(ticksLE,data_LECHN,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('China LE per capita in PPP international USD of 2017')
title('China LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LECHNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LECHNAbsSince1990Annual.png')
saveas(gcf,'Plot_LECHNAbsSince1990Annual.epsc')


%% Plot - growth rates

fig93 = figure
plot(ticksdlLE,dldata_LECHN,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of China LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of China LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLECHNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLECHNAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLECHNAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig94 = figure
histogram(data_LECHN,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('China LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LECHNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LECHNAbsSince1990Annual.png')
saveas(gcf,'Hist_LECHNAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig95 = figure
histogram(dldata_LECHN,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of China LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLECHNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLECHNAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLECHNAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LECHNAbs_min = min(data_LECHN)
data_LECHNAbs_max = max(data_LECHN)
data_LECHNAbs_range = data_LECHNAbs_max - data_LECHNAbs_min
stripe_LECHNAbs_range = data_LECHNAbs_range/16
data_LECHNAbs_mean = mean(data_LECHN)
data_LECHNAbs_median = median(data_LECHN)
%data_LECHNAbs_mode = mode(data_LECHN,'all') %AM230708 Sth's wrong about the mode command?!

tabLECHNAbs = table(categorical({'data_LECHNAbs_min';'data_LECHNAbs_max';'data_LECHNAbs_range';'stripe_LECHNAbs_range';'data_LECHNAbs_mean';'data_LECHNAbs_median'}),{data_LECHNAbs_min; data_LECHNAbs_max; data_LECHNAbs_range; stripe_LECHNAbs_range; data_LECHNAbs_mean; data_LECHNAbs_median})
writetable(tabLECHNAbs,'tabLECHNUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LECHNAbs_min = min(dldata_LECHN);
dldata_LECHNAbs_max = max(dldata_LECHN);
dldata_LECHNAbs_range = dldata_LECHNAbs_max - dldata_LECHNAbs_min;
dlstripe_LECHNAbs_range = dldata_LECHNAbs_range/16;
dldata_LECHNAbs_mean = mean(dldata_LECHN);
dldata_LECHNAbs_median = median(dldata_LECHN);
%dldata_LECHNAbs_mode = mode(dldata_LECHN,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LECHNAbs_std = std(dldata_LECHN);

tabdlLECHNAbs = table(categorical({'dldata_LECHNAbs_min';'dldata_LECHNAbs_max';'dldata_LECHNAbs_range';'dlstripe_LECHNAbs_range';'dldata_LECHNAbs_mean';'dldata_LECHNAbs_median'; 'dldata_LECHNAbs_std'}),{dldata_LECHNAbs_min; dldata_LECHNAbs_max; dldata_LECHNAbs_range; stripe_LECHNAbs_range; dldata_LECHNAbs_mean; dldata_LECHNAbs_median; dldata_LECHNAbs_std});
writetable(tabdlLECHNAbs,'tabdlLECHNUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the CHN CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig96 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcCHNMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in China per capita for 1990-2020');
title('China');

saveas(gcf,'CO2CHNpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2CHNpcAbs.png')
saveas(gcf,'CO2CHNpcAbs.epsc')

CO2CHNpcAbs = imread('CO2CHNpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig97 = figure
plot(ticksCO2,data_CO2pcCHNMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('China CO2 emissions pc, in metric tons')
title('China CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcCHNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcCHNMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcCHNMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig98 = figure
plot(ticksdlCO2,dldata_CO2pcCHNMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of China CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of China CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcCHNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcCHNMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcCHNMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig99 = figure
histogram(data_CO2pcCHNMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('China CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcCHNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcCHNMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcCHNMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig100 = figure
histogram(dldata_CO2pcCHNMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of China CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcCHNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcCHNMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcCHNMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcCHNMetricTonsAbs_min = min(data_CO2pcCHNMetricTons)
data_CO2pcCHNMetricTonsAbs_max = max(data_CO2pcCHNMetricTons)
data_CO2pcCHNMetricTonsAbs_range = data_CO2pcCHNMetricTonsAbs_max - data_CO2pcCHNMetricTonsAbs_min
stripe_CO2pcCHNMetricTonsAbs_range = data_CO2pcCHNMetricTonsAbs_range/16
data_CO2pcCHNMetricTonsAbs_mean = mean(data_CO2pcCHNMetricTons)
data_CO2pcCHNMetricTonsAbs_median = median(data_CO2pcCHNMetricTons)
%data_CO2pcCHNMetricTonsAbs_mode = mode(data_CO2pcCHNMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcCHNMetricTonsAbs = table(categorical({'data_CO2pcCHNMetricTonsAbs_min';'data_CO2pcCHNMetricTonsAbs_max';'data_CO2pcCHNMetricTons_range';'stripe_CO2pcCHNMetricTonsAbs_range';'data_CO2pcCHNMetricTonsAbs_mean';'data_CO2pcCHNMetricTonsAbs_median'}),{data_CO2pcCHNMetricTonsAbs_min; data_CO2pcCHNMetricTonsAbs_max; data_CO2pcCHNMetricTonsAbs_range; stripe_CO2pcCHNMetricTonsAbs_range; data_CO2pcCHNMetricTonsAbs_mean; data_CO2pcCHNMetricTonsAbs_median})
writetable(tabCO2pcCHNMetricTonsAbs,'tabCO2pcCHNMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcCHNMetricTonsAbs_min = min(dldata_CO2pcCHNMetricTons);
dldata_CO2pcCHNMetricTonsAbs_max = max(dldata_CO2pcCHNMetricTons);
dldata_CO2pcCHNMetricTonsAbs_range = dldata_CO2pcCHNMetricTonsAbs_max - dldata_CO2pcCHNMetricTonsAbs_min;
dlstripe_CO2pcCHNMetricTonsAbs_range = dldata_CO2pcCHNMetricTonsAbs_range/16;
dldata_CO2pcCHNMetricTonsAbs_mean = mean(dldata_CO2pcCHNMetricTons);
dldata_CO2pcCHNMetricTonsAbs_median = median(dldata_CO2pcCHNMetricTons);
%dldata_CO2pcCHNMetricTonsAbs_mode = mode(dldata_CO2pcCHNMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcCHNMetricTonsAbs_std = std(dldata_CO2pcCHNMetricTons);

tabdlCO2pcCHNMetricTonsAbs = table(categorical({'data_CO2pcCHNMetricTonsAbs_min';'data_CO2pcCHNMetricTonsAbs_max';'data_CO2pcCHNMetricTons_range';'stripe_CO2pcCHNMetricTonsAbs_range';'data_CO2pcCHNMetricTonsAbs_mean';'data_CO2pcCHNMetricTonsAbs_median'; 'dldata_CO2pcCHNMetricTonsAbs_std'}),{data_CO2pcCHNMetricTonsAbs_min; data_CO2pcCHNMetricTonsAbs_max; data_CO2pcCHNMetricTonsAbs_range; stripe_CO2pcCHNMetricTonsAbs_range; data_CO2pcCHNMetricTonsAbs_mean; data_CO2pcCHNMetricTonsAbs_median; dldata_CO2pcCHNMetricTonsAbs_std})
writetable(tabdlCO2pcCHNMetricTonsAbs,'tabdlCO2pcCHNMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the CHN Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig101 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcCHNDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('China Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('China');

saveas(gcf,'GreenProspDefLEPPPUSD2017CHNpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017CHNpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017CHNpcAbs.epsc')

CO2CHNpcAbs = imread('CO2CHNpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig102 = figure
plot(ticksGreenProspLE,data_GreenProsppcCHNDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('China greening prosperity ratio pc (LE pc / CO2 pc)')
title('China Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017CHNpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017CHNpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017CHNpcAbs.epsc')

%% Plot - growth rates

fig103 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcCHNDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of China greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of China Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017CHNpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017CHNpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017CHNpcAbs.epsc')


%% Histogram - absolute level

fig104 = figure
histogram(data_GreenProsppcCHNDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('China Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017CHNpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017CHNpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017CHNpcAbs.epsc')

%% Histogram - growth rates

fig105 = figure
histogram(dldata_GreenProsppcCHNDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of China Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017CHNAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017CHNAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017CHNAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcCHNDefByLEAbs_min = min(data_GreenProsppcCHNDefByLE);
data_GreenProsppcCHNDefByLEAbs_max = max(data_GreenProsppcCHNDefByLE);
data_GreenProsppcCHNDefByLEAbs_range = data_GreenProsppcCHNDefByLEAbs_max - data_GreenProsppcCHNDefByLEAbs_min;
stripe_GreenProsppcCHNDefByLEAbs_range = data_GreenProsppcCHNDefByLEAbs_range/16;
data_GreenProsppcCHNDefByLEAbs_mean = mean(data_GreenProsppcCHNDefByLE);
data_GreenProsppcCHNDefByLEAbs_median = median(data_GreenProsppcCHNDefByLE);
%data_GreenProsppcCHNDefByLEAbs_mode = mode(data_GreenProsppcCHNDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcCHNDefByLEAbs_std = std(data_GreenProsppcCHNDefByLE);

tabGreenProsppcCHNDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcCHNDefByLEAbs_min';'data_GreenProsppcCHNDefByLEAbs_max';'data_GreenProsppcCHNDefByLE_range';'stripe_GreenProsppcCHNDefByLEAbs_range';'data_GreenProsppcCHNDefByLEAbs_mean';'data_GreenProsppcCHNDefByLEAbs_median'; 'data_GreenProsppcCHNDefByLEAbs_std'}),{data_GreenProsppcCHNDefByLEAbs_min; data_GreenProsppcCHNDefByLEAbs_max; data_GreenProsppcCHNDefByLEAbs_range; stripe_GreenProsppcCHNDefByLEAbs_range; data_GreenProsppcCHNDefByLEAbs_mean; data_GreenProsppcCHNDefByLEAbs_median; data_GreenProsppcCHNDefByLEAbs_std});
writetable(tabGreenProsppcCHNDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcCHNDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcCHNDefByLEAbs_min = min(dldata_GreenProsppcCHNDefByLE);
dldata_GreenProsppcCHNDefByLEAbs_max = max(dldata_GreenProsppcCHNDefByLE);
dldata_GreenProsppcCHNDefByLEAbs_range = dldata_GreenProsppcCHNDefByLEAbs_max - dldata_GreenProsppcCHNDefByLEAbs_min;
dlstripe_GreenProsppcCHNDefByLEAbs_range = dldata_GreenProsppcCHNDefByLEAbs_range/16;
dldata_GreenProsppcCHNDefByLEAbs_mean = mean(dldata_GreenProsppcCHNDefByLE);
dldata_GreenProsppcCHNDefByLEAbs_median = median(dldata_GreenProsppcCHNDefByLE);
%dldata_GreenProsppcCHNDefByLEAbs_mode = mode(dldata_GreenProsppcCHNDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcCHNDefByLEAbs_std = std(dldata_GreenProsppcCHNDefByLE);

tabdlGreenProsppcCHNDefByLEAbs = table(categorical({'dldata_GreenProsppcCHNDefByLEAbs_min';'dldata_GreenProsppcCHNDefByLEAbs_max';'dldata_GreenProsppcCHNDefByLE_range';'dlstripe_GreenProsppcCHNDefByLEAbs_range';'dldata_GreenProsppcCHNDefByLEAbs_mean'; 'dldata_GreenProsppcCHNDefByLEAbs_median';'dldata_GreenProsppcCHNDefByLEAbs_std'}),{dldata_GreenProsppcCHNDefByLEAbs_min; dldata_GreenProsppcCHNDefByLEAbs_max; dldata_GreenProsppcCHNDefByLEAbs_range; dlstripe_GreenProsppcCHNDefByLEAbs_range; dldata_GreenProsppcCHNDefByLEAbs_mean; dldata_GreenProsppcCHNDefByLEAbs_median; dldata_GreenProsppcCHNDefByLEAbs_std});
writetable(tabdlGreenProsppcCHNDefByLEAbs ,'tabdlGreenProsppcCHNDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Brazil - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEBRA = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI34:BM34');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEBRA = log(data_LEBRA);
dldata_LEBRA = diff(ldata_LEBRA)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcBRAMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI34:BM34');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcBRAMetricTons = log(data_CO2pcBRAMetricTons);
dldata_CO2pcBRAMetricTons = diff(ldata_CO2pcBRAMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcBRADefByLE = data_LEBRA ./ data_CO2pcBRAMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcBRADefByLE = log(data_GreenProsppcBRADefByLE);
dldata_GreenProsppcBRADefByLE = diff(ldata_GreenProsppcBRADefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the BRA LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig106 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEBRA)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('Brazil LE per capita in PPP International USD of 2017 for 1990-1990');
title('Brazil');

saveas(gcf,'LEBRApcAbs.fig') %AM230701 checking online
saveas(gcf,'LEBRApcAbs.png')
saveas(gcf,'LEBRApcAbs.epsc')

LEBRApcDev = imread('LEBRApcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig107 = figure
plot(ticksLE,data_LEBRA,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Brazil LE per capita in PPP international USD of 2017')
title('Brazil LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEBRAAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEBRAAbsSince1990Annual.png')
saveas(gcf,'Plot_LEBRAAbsSince1990Annual.epsc')


%% Plot - growth rates

fig108 = figure
plot(ticksdlLE,dldata_LEBRA,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of Brazil LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of Brazil LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEBRAAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEBRAAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEBRAAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig109 = figure
histogram(data_LEBRA,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Brazil LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEBRAAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEBRAAbsSince1990Annual.png')
saveas(gcf,'Hist_LEBRAAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig110 = figure
histogram(dldata_LEBRA,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of Brazil LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEBRAAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEBRAAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEBRAAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEBRAAbs_min = min(data_LEBRA)
data_LEBRAAbs_max = max(data_LEBRA)
data_LEBRAAbs_range = data_LEBRAAbs_max - data_LEBRAAbs_min
stripe_LEBRAAbs_range = data_LEBRAAbs_range/16
data_LEBRAAbs_mean = mean(data_LEBRA)
data_LEBRAAbs_median = median(data_LEBRA)
%data_LEBRAAbs_mode = mode(data_LEBRA,'all') %AM230708 Sth's wrong about the mode command?!

tabLEBRAAbs = table(categorical({'data_LEBRAAbs_min';'data_LEBRAAbs_max';'data_LEBRAAbs_range';'stripe_LEBRAAbs_range';'data_LEBRAAbs_mean';'data_LEBRAAbs_median'}),{data_LEBRAAbs_min; data_LEBRAAbs_max; data_LEBRAAbs_range; stripe_LEBRAAbs_range; data_LEBRAAbs_mean; data_LEBRAAbs_median})
writetable(tabLEBRAAbs,'tabLEBRAUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEBRAAbs_min = min(dldata_LEBRA);
dldata_LEBRAAbs_max = max(dldata_LEBRA);
dldata_LEBRAAbs_range = dldata_LEBRAAbs_max - dldata_LEBRAAbs_min;
dlstripe_LEBRAAbs_range = dldata_LEBRAAbs_range/16;
dldata_LEBRAAbs_mean = mean(dldata_LEBRA);
dldata_LEBRAAbs_median = median(dldata_LEBRA);
%dldata_LEBRAAbs_mode = mode(dldata_LEBRA,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEBRAAbs_std = std(dldata_LEBRA);

tabdlLEBRAAbs = table(categorical({'dldata_LEBRAAbs_min';'dldata_LEBRAAbs_max';'dldata_LEBRAAbs_range';'dlstripe_LEBRAAbs_range';'dldata_LEBRAAbs_mean';'dldata_LEBRAAbs_median'; 'dldata_LEBRAAbs_std'}),{dldata_LEBRAAbs_min; dldata_LEBRAAbs_max; dldata_LEBRAAbs_range; stripe_LEBRAAbs_range; dldata_LEBRAAbs_mean; dldata_LEBRAAbs_median; dldata_LEBRAAbs_std});
writetable(tabdlLEBRAAbs,'tabdlLEBRAUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the BRA CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig111 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcBRAMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in Brzail per capita for 1990-2020');
title('Brazil');

saveas(gcf,'CO2BRApcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2BRApcAbs.png')
saveas(gcf,'CO2BRApcAbs.epsc')

CO2BRApcAbs = imread('CO2BRApcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig112 = figure
plot(ticksCO2,data_CO2pcBRAMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Brazil CO2 emissions pc, in metric tons')
title('Brazil CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcBRAMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcBRAMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcBRAMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig113 = figure
plot(ticksdlCO2,dldata_CO2pcBRAMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of Brazil CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of Brazil CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcBRAMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcBRAMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcBRAMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig114 = figure
histogram(data_CO2pcBRAMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Brazil CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcBRAMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcBRAMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcBRAMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig115 = figure
histogram(dldata_CO2pcBRAMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of Brazil CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcBRAMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcBRAMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcBRAMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcBRAMetricTonsAbs_min = min(data_CO2pcBRAMetricTons)
data_CO2pcBRAMetricTonsAbs_max = max(data_CO2pcBRAMetricTons)
data_CO2pcBRAMetricTonsAbs_range = data_CO2pcBRAMetricTonsAbs_max - data_CO2pcBRAMetricTonsAbs_min
stripe_CO2pcBRAMetricTonsAbs_range = data_CO2pcBRAMetricTonsAbs_range/16
data_CO2pcBRAMetricTonsAbs_mean = mean(data_CO2pcBRAMetricTons)
data_CO2pcBRAMetricTonsAbs_median = median(data_CO2pcBRAMetricTons)
%data_CO2pcBRAMetricTonsAbs_mode = mode(data_CO2pcBRAMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcBRAMetricTonsAbs = table(categorical({'data_CO2pcBRAMetricTonsAbs_min';'data_CO2pcBRAMetricTonsAbs_max';'data_CO2pcBRAMetricTons_range';'stripe_CO2pcBRAMetricTonsAbs_range';'data_CO2pcBRAMetricTonsAbs_mean';'data_CO2pcBRAMetricTonsAbs_median'}),{data_CO2pcBRAMetricTonsAbs_min; data_CO2pcBRAMetricTonsAbs_max; data_CO2pcBRAMetricTonsAbs_range; stripe_CO2pcBRAMetricTonsAbs_range; data_CO2pcBRAMetricTonsAbs_mean; data_CO2pcBRAMetricTonsAbs_median})
writetable(tabCO2pcBRAMetricTonsAbs,'tabCO2pcBRAMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcBRAMetricTonsAbs_min = min(dldata_CO2pcBRAMetricTons);
dldata_CO2pcBRAMetricTonsAbs_max = max(dldata_CO2pcBRAMetricTons);
dldata_CO2pcBRAMetricTonsAbs_range = dldata_CO2pcBRAMetricTonsAbs_max - dldata_CO2pcBRAMetricTonsAbs_min;
dlstripe_CO2pcBRAMetricTonsAbs_range = dldata_CO2pcBRAMetricTonsAbs_range/16;
dldata_CO2pcBRAMetricTonsAbs_mean = mean(dldata_CO2pcBRAMetricTons);
dldata_CO2pcBRAMetricTonsAbs_median = median(dldata_CO2pcBRAMetricTons);
%dldata_CO2pcBRAMetricTonsAbs_mode = mode(dldata_CO2pcBRAMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcBRAMetricTonsAbs_std = std(dldata_CO2pcBRAMetricTons);

tabdlCO2pcBRAMetricTonsAbs = table(categorical({'data_CO2pcBRAMetricTonsAbs_min';'data_CO2pcBRAMetricTonsAbs_max';'data_CO2pcBRAMetricTons_range';'stripe_CO2pcBRAMetricTonsAbs_range';'data_CO2pcBRAMetricTonsAbs_mean';'data_CO2pcBRAMetricTonsAbs_median'; 'dldata_CO2pcBRAMetricTonsAbs_std'}),{data_CO2pcBRAMetricTonsAbs_min; data_CO2pcBRAMetricTonsAbs_max; data_CO2pcBRAMetricTonsAbs_range; stripe_CO2pcBRAMetricTonsAbs_range; data_CO2pcBRAMetricTonsAbs_mean; data_CO2pcBRAMetricTonsAbs_median; dldata_CO2pcBRAMetricTonsAbs_std})
writetable(tabdlCO2pcBRAMetricTonsAbs,'tabdlCO2pcBRAMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the BRA Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig116 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcBRADefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('Brazil Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('Brazil');

saveas(gcf,'GreenProspDefLEPPPUSD2017BRApcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017BRApcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017BRApcAbs.epsc')

CO2BRApcAbs = imread('CO2BRApcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig117 = figure
plot(ticksGreenProspLE,data_GreenProsppcBRADefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Brazil greening prosperity ratio pc (LE pc / CO2 pc)')
title('Brazil Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017BRApcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017BRApcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017BRApcAbs.epsc')

%% Plot - growth rates

fig118 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcBRADefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of Brazil greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of Brazil Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017BRApcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017BRApcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017BRApcAbs.epsc')


%% Histogram - absolute level

fig119 = figure
histogram(data_GreenProsppcBRADefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Brazil Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017BRApcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017BRApcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017BRApcAbs.epsc')

%% Histogram - growth rates

fig120 = figure
histogram(dldata_GreenProsppcBRADefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of Brazil Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017BRAAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017BRAAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017BRAAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcBRADefByLEAbs_min = min(data_GreenProsppcBRADefByLE);
data_GreenProsppcBRADefByLEAbs_max = max(data_GreenProsppcBRADefByLE);
data_GreenProsppcBRADefByLEAbs_range = data_GreenProsppcBRADefByLEAbs_max - data_GreenProsppcBRADefByLEAbs_min;
stripe_GreenProsppcBRADefByLEAbs_range = data_GreenProsppcBRADefByLEAbs_range/16;
data_GreenProsppcBRADefByLEAbs_mean = mean(data_GreenProsppcBRADefByLE);
data_GreenProsppcBRADefByLEAbs_median = median(data_GreenProsppcBRADefByLE);
%data_GreenProsppcBRADefByLEAbs_mode = mode(data_GreenProsppcBRADefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcBRADefByLEAbs_std = std(data_GreenProsppcBRADefByLE);

tabGreenProsppcBRADefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcBRADefByLEAbs_min';'data_GreenProsppcBRADefByLEAbs_max';'data_GreenProsppcBRADefByLE_range';'stripe_GreenProsppcBRADefByLEAbs_range';'data_GreenProsppcBRADefByLEAbs_mean';'data_GreenProsppcBRADefByLEAbs_median'; 'data_GreenProsppcBRADefByLEAbs_std'}),{data_GreenProsppcBRADefByLEAbs_min; data_GreenProsppcBRADefByLEAbs_max; data_GreenProsppcBRADefByLEAbs_range; stripe_GreenProsppcBRADefByLEAbs_range; data_GreenProsppcBRADefByLEAbs_mean; data_GreenProsppcBRADefByLEAbs_median; data_GreenProsppcBRADefByLEAbs_std});
writetable(tabGreenProsppcBRADefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcBRADefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcBRADefByLEAbs_min = min(dldata_GreenProsppcBRADefByLE);
dldata_GreenProsppcBRADefByLEAbs_max = max(dldata_GreenProsppcBRADefByLE);
dldata_GreenProsppcBRADefByLEAbs_range = dldata_GreenProsppcBRADefByLEAbs_max - dldata_GreenProsppcBRADefByLEAbs_min;
dlstripe_GreenProsppcBRADefByLEAbs_range = dldata_GreenProsppcBRADefByLEAbs_range/16;
dldata_GreenProsppcBRADefByLEAbs_mean = mean(dldata_GreenProsppcBRADefByLE);
dldata_GreenProsppcBRADefByLEAbs_median = median(dldata_GreenProsppcBRADefByLE);
%dldata_GreenProsppcBRADefByLEAbs_mode = mode(dldata_GreenProsppcBRADefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcBRADefByLEAbs_std = std(dldata_GreenProsppcBRADefByLE);

tabdlGreenProsppcBRADefByLEAbs = table(categorical({'dldata_GreenProsppcBRADefByLEAbs_min';'dldata_GreenProsppcBRADefByLEAbs_max';'dldata_GreenProsppcBRADefByLE_range';'dlstripe_GreenProsppcBRADefByLEAbs_range';'dldata_GreenProsppcBRADefByLEAbs_mean'; 'dldata_GreenProsppcBRADefByLEAbs_median';'dldata_GreenProsppcBRADefByLEAbs_std'}),{dldata_GreenProsppcBRADefByLEAbs_min; dldata_GreenProsppcBRADefByLEAbs_max; dldata_GreenProsppcBRADefByLEAbs_range; dlstripe_GreenProsppcBRADefByLEAbs_range; dldata_GreenProsppcBRADefByLEAbs_mean; dldata_GreenProsppcBRADefByLEAbs_median; dldata_GreenProsppcBRADefByLEAbs_std});
writetable(tabdlGreenProsppcBRADefByLEAbs ,'tabdlGreenProsppcBRADefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Australia - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEAUS = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI18:BM18');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEAUS = log(data_LEAUS);
dldata_LEAUS = diff(ldata_LEAUS)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcAUSMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI18:BM18');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcAUSMetricTons = log(data_CO2pcAUSMetricTons);
dldata_CO2pcAUSMetricTons = diff(ldata_CO2pcAUSMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcAUSDefByLE = data_LEAUS ./ data_CO2pcAUSMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcAUSDefByLE = log(data_GreenProsppcAUSDefByLE);
dldata_GreenProsppcAUSDefByLE = diff(ldata_GreenProsppcAUSDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the AUS LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig121 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEAUS)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('Australia LE per capita in PPP International USD of 2017 for 1990-1990');
title('Australia');

saveas(gcf,'LEAUSpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEAUSpcAbs.png')
saveas(gcf,'LEAUSpcAbs.epsc')

LEAUSpcDev = imread('LEAUSpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig122 = figure
plot(ticksLE,data_LEAUS,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Australia LE per capita in PPP international USD of 2017')
title('Australia LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEAUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEAUSAbsSince1990Annual.png')
saveas(gcf,'Plot_LEAUSAbsSince1990Annual.epsc')


%% Plot - growth rates

fig123 = figure
plot(ticksdlLE,dldata_LEAUS,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of Australia LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of Australia LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEAUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEAUSAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEAUSAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig124 = figure
histogram(data_LEAUS,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Australia LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEAUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEAUSAbsSince1990Annual.png')
saveas(gcf,'Hist_LEAUSAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig125 = figure
histogram(dldata_LEAUS,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of Australia LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEAUSAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEAUSAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEAUSAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEAUSAbs_min = min(data_LEAUS)
data_LEAUSAbs_max = max(data_LEAUS)
data_LEAUSAbs_range = data_LEAUSAbs_max - data_LEAUSAbs_min
stripe_LEAUSAbs_range = data_LEAUSAbs_range/16
data_LEAUSAbs_mean = mean(data_LEAUS)
data_LEAUSAbs_median = median(data_LEAUS)
%data_LEAUSAbs_mode = mode(data_LEAUS,'all') %AM230708 Sth's wrong about the mode command?!

tabLEAUSAbs = table(categorical({'data_LEAUSAbs_min';'data_LEAUSAbs_max';'data_LEAUSAbs_range';'stripe_LEAUSAbs_range';'data_LEAUSAbs_mean';'data_LEAUSAbs_median'}),{data_LEAUSAbs_min; data_LEAUSAbs_max; data_LEAUSAbs_range; stripe_LEAUSAbs_range; data_LEAUSAbs_mean; data_LEAUSAbs_median})
writetable(tabLEAUSAbs,'tabLEAUSUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEAUSAbs_min = min(dldata_LEAUS);
dldata_LEAUSAbs_max = max(dldata_LEAUS);
dldata_LEAUSAbs_range = dldata_LEAUSAbs_max - dldata_LEAUSAbs_min;
dlstripe_LEAUSAbs_range = dldata_LEAUSAbs_range/16;
dldata_LEAUSAbs_mean = mean(dldata_LEAUS);
dldata_LEAUSAbs_median = median(dldata_LEAUS);
%dldata_LEAUSAbs_mode = mode(dldata_LEAUS,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEAUSAbs_std = std(dldata_LEAUS);

tabdlLEAUSAbs = table(categorical({'dldata_LEAUSAbs_min';'dldata_LEAUSAbs_max';'dldata_LEAUSAbs_range';'dlstripe_LEAUSAbs_range';'dldata_LEAUSAbs_mean';'dldata_LEAUSAbs_median'; 'dldata_LEAUSAbs_std'}),{dldata_LEAUSAbs_min; dldata_LEAUSAbs_max; dldata_LEAUSAbs_range; stripe_LEAUSAbs_range; dldata_LEAUSAbs_mean; dldata_LEAUSAbs_median; dldata_LEAUSAbs_std});
writetable(tabdlLEAUSAbs,'tabdlLEAUSUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the AUS CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig126 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcAUSMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in Australia per capita for 1990-2020');
title('Australia');

saveas(gcf,'CO2AUSpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2AUSpcAbs.png')
saveas(gcf,'CO2AUSpcAbs.epsc')

CO2AUSpcAbs = imread('CO2AUSpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig127 = figure
plot(ticksCO2,data_CO2pcAUSMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Australia CO2 emissions pc, in metric tons')
title('Australia CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcAUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcAUSMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcAUSMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig128 = figure
plot(ticksdlCO2,dldata_CO2pcAUSMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of Australia CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of Australia CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcAUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcAUSMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcAUSMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig129 = figure
histogram(data_CO2pcAUSMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Australia CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcAUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcAUSMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcAUSMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig130 = figure
histogram(dldata_CO2pcAUSMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of Australia CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcAUSMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcAUSMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcAUSMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcAUSMetricTonsAbs_min = min(data_CO2pcAUSMetricTons)
data_CO2pcAUSMetricTonsAbs_max = max(data_CO2pcAUSMetricTons)
data_CO2pcAUSMetricTonsAbs_range = data_CO2pcAUSMetricTonsAbs_max - data_CO2pcAUSMetricTonsAbs_min
stripe_CO2pcAUSMetricTonsAbs_range = data_CO2pcAUSMetricTonsAbs_range/16
data_CO2pcAUSMetricTonsAbs_mean = mean(data_CO2pcAUSMetricTons)
data_CO2pcAUSMetricTonsAbs_median = median(data_CO2pcAUSMetricTons)
%data_CO2pcAUSMetricTonsAbs_mode = mode(data_CO2pcAUSMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcAUSMetricTonsAbs = table(categorical({'data_CO2pcAUSMetricTonsAbs_min';'data_CO2pcAUSMetricTonsAbs_max';'data_CO2pcAUSMetricTons_range';'stripe_CO2pcAUSMetricTonsAbs_range';'data_CO2pcAUSMetricTonsAbs_mean';'data_CO2pcAUSMetricTonsAbs_median'}),{data_CO2pcAUSMetricTonsAbs_min; data_CO2pcAUSMetricTonsAbs_max; data_CO2pcAUSMetricTonsAbs_range; stripe_CO2pcAUSMetricTonsAbs_range; data_CO2pcAUSMetricTonsAbs_mean; data_CO2pcAUSMetricTonsAbs_median})
writetable(tabCO2pcAUSMetricTonsAbs,'tabCO2pcAUSMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcAUSMetricTonsAbs_min = min(dldata_CO2pcAUSMetricTons);
dldata_CO2pcAUSMetricTonsAbs_max = max(dldata_CO2pcAUSMetricTons);
dldata_CO2pcAUSMetricTonsAbs_range = dldata_CO2pcAUSMetricTonsAbs_max - dldata_CO2pcAUSMetricTonsAbs_min;
dlstripe_CO2pcAUSMetricTonsAbs_range = dldata_CO2pcAUSMetricTonsAbs_range/16;
dldata_CO2pcAUSMetricTonsAbs_mean = mean(dldata_CO2pcAUSMetricTons);
dldata_CO2pcAUSMetricTonsAbs_median = median(dldata_CO2pcAUSMetricTons);
%dldata_CO2pcAUSMetricTonsAbs_mode = mode(dldata_CO2pcAUSMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcAUSMetricTonsAbs_std = std(dldata_CO2pcAUSMetricTons);

tabdlCO2pcAUSMetricTonsAbs = table(categorical({'data_CO2pcAUSMetricTonsAbs_min';'data_CO2pcAUSMetricTonsAbs_max';'data_CO2pcAUSMetricTons_range';'stripe_CO2pcAUSMetricTonsAbs_range';'data_CO2pcAUSMetricTonsAbs_mean';'data_CO2pcAUSMetricTonsAbs_median'; 'dldata_CO2pcAUSMetricTonsAbs_std'}),{data_CO2pcAUSMetricTonsAbs_min; data_CO2pcAUSMetricTonsAbs_max; data_CO2pcAUSMetricTonsAbs_range; stripe_CO2pcAUSMetricTonsAbs_range; data_CO2pcAUSMetricTonsAbs_mean; data_CO2pcAUSMetricTonsAbs_median; dldata_CO2pcAUSMetricTonsAbs_std})
writetable(tabdlCO2pcAUSMetricTonsAbs,'tabdlCO2pcAUSMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the AUS Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig131 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcAUSDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('Australia Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('Australia');

saveas(gcf,'GreenProspDefLEPPPUSD2017AUSpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017AUSpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017AUSpcAbs.epsc')

CO2AUSpcAbs = imread('CO2AUSpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig132 = figure
plot(ticksGreenProspLE,data_GreenProsppcAUSDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Australia greening prosperity ratio pc (LE pc / CO2 pc)')
title('Australia Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017AUSpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017AUSpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017AUSpcAbs.epsc')

%% Plot - growth rates

fig133 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcAUSDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of Australia greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of Australia Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017AUSpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017AUSpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017AUSpcAbs.epsc')


%% Histogram - absolute level

fig134 = figure
histogram(data_GreenProsppcAUSDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Australia Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017AUSpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017AUSpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017AUSpcAbs.epsc')

%% Histogram - growth rates

fig135 = figure
histogram(dldata_GreenProsppcAUSDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of Australia Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017AUSAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017AUSAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017AUSAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcAUSDefByLEAbs_min = min(data_GreenProsppcAUSDefByLE);
data_GreenProsppcAUSDefByLEAbs_max = max(data_GreenProsppcAUSDefByLE);
data_GreenProsppcAUSDefByLEAbs_range = data_GreenProsppcAUSDefByLEAbs_max - data_GreenProsppcAUSDefByLEAbs_min;
stripe_GreenProsppcAUSDefByLEAbs_range = data_GreenProsppcAUSDefByLEAbs_range/16;
data_GreenProsppcAUSDefByLEAbs_mean = mean(data_GreenProsppcAUSDefByLE);
data_GreenProsppcAUSDefByLEAbs_median = median(data_GreenProsppcAUSDefByLE);
%data_GreenProsppcAUSDefByLEAbs_mode = mode(data_GreenProsppcAUSDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcAUSDefByLEAbs_std = std(data_GreenProsppcAUSDefByLE);

tabGreenProsppcAUSDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcAUSDefByLEAbs_min';'data_GreenProsppcAUSDefByLEAbs_max';'data_GreenProsppcAUSDefByLE_range';'stripe_GreenProsppcAUSDefByLEAbs_range';'data_GreenProsppcAUSDefByLEAbs_mean';'data_GreenProsppcAUSDefByLEAbs_median'; 'data_GreenProsppcAUSDefByLEAbs_std'}),{data_GreenProsppcAUSDefByLEAbs_min; data_GreenProsppcAUSDefByLEAbs_max; data_GreenProsppcAUSDefByLEAbs_range; stripe_GreenProsppcAUSDefByLEAbs_range; data_GreenProsppcAUSDefByLEAbs_mean; data_GreenProsppcAUSDefByLEAbs_median; data_GreenProsppcAUSDefByLEAbs_std});
writetable(tabGreenProsppcAUSDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcAUSDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcAUSDefByLEAbs_min = min(dldata_GreenProsppcAUSDefByLE);
dldata_GreenProsppcAUSDefByLEAbs_max = max(dldata_GreenProsppcAUSDefByLE);
dldata_GreenProsppcAUSDefByLEAbs_range = dldata_GreenProsppcAUSDefByLEAbs_max - dldata_GreenProsppcAUSDefByLEAbs_min;
dlstripe_GreenProsppcAUSDefByLEAbs_range = dldata_GreenProsppcAUSDefByLEAbs_range/16;
dldata_GreenProsppcAUSDefByLEAbs_mean = mean(dldata_GreenProsppcAUSDefByLE);
dldata_GreenProsppcAUSDefByLEAbs_median = median(dldata_GreenProsppcAUSDefByLE);
%dldata_GreenProsppcAUSDefByLEAbs_mode = mode(dldata_GreenProsppcAUSDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcAUSDefByLEAbs_std = std(dldata_GreenProsppcAUSDefByLE);

tabdlGreenProsppcAUSDefByLEAbs = table(categorical({'dldata_GreenProsppcAUSDefByLEAbs_min';'dldata_GreenProsppcAUSDefByLEAbs_max';'dldata_GreenProsppcAUSDefByLE_range';'dlstripe_GreenProsppcAUSDefByLEAbs_range';'dldata_GreenProsppcAUSDefByLEAbs_mean'; 'dldata_GreenProsppcAUSDefByLEAbs_median';'dldata_GreenProsppcAUSDefByLEAbs_std'}),{dldata_GreenProsppcAUSDefByLEAbs_min; dldata_GreenProsppcAUSDefByLEAbs_max; dldata_GreenProsppcAUSDefByLEAbs_range; dlstripe_GreenProsppcAUSDefByLEAbs_range; dldata_GreenProsppcAUSDefByLEAbs_mean; dldata_GreenProsppcAUSDefByLEAbs_median; dldata_GreenProsppcAUSDefByLEAbs_std});
writetable(tabdlGreenProsppcAUSDefByLEAbs ,'tabdlGreenProsppcAUSDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% European Union - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEEU = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI78:BM78');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEEU = log(data_LEEU);
dldata_LEEU = diff(ldata_LEEU)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcEUMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI78:BM78');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcEUMetricTons = log(data_CO2pcEUMetricTons);
dldata_CO2pcEUMetricTons = diff(ldata_CO2pcEUMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcEUDefByLE = data_LEEU ./ data_CO2pcEUMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcEUDefByLE = log(data_GreenProsppcEUDefByLE);
dldata_GreenProsppcEUDefByLE = diff(ldata_GreenProsppcEUDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the EU LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig136 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEEU)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('EU LE per capita in PPP International USD of 2017 for 1990-1990');
title('EU');

saveas(gcf,'LEEUpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEEUpcAbs.png')
saveas(gcf,'LEEUpcAbs.epsc')

LEEUpcDev = imread('LEEUpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig137 = figure
plot(ticksLE,data_LEEU,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('EU LE per capita in PPP international USD of 2017')
title('EU LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEEUAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEEUAbsSince1990Annual.png')
saveas(gcf,'Plot_LEEUAbsSince1990Annual.epsc')


%% Plot - growth rates

fig138 = figure
plot(ticksdlLE,dldata_LEEU,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of EU LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of EU LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEEUAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEEUAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEEUAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig139 = figure
histogram(data_LEEU,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('EU LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEEUAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEEUAbsSince1990Annual.png')
saveas(gcf,'Hist_LEEUAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig140 = figure
histogram(dldata_LEEU,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of EU LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEEUAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEEUAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEEUAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEEUAbs_min = min(data_LEEU)
data_LEEUAbs_max = max(data_LEEU)
data_LEEUAbs_range = data_LEEUAbs_max - data_LEEUAbs_min
stripe_LEEUAbs_range = data_LEEUAbs_range/16
data_LEEUAbs_mean = mean(data_LEEU)
data_LEEUAbs_median = median(data_LEEU)
%data_LEEUAbs_mode = mode(data_LEEU,'all') %AM230708 Sth's wrong about the mode command?!

tabLEEUAbs = table(categorical({'data_LEEUAbs_min';'data_LEEUAbs_max';'data_LEEUAbs_range';'stripe_LEEUAbs_range';'data_LEEUAbs_mean';'data_LEEUAbs_median'}),{data_LEEUAbs_min; data_LEEUAbs_max; data_LEEUAbs_range; stripe_LEEUAbs_range; data_LEEUAbs_mean; data_LEEUAbs_median})
writetable(tabLEEUAbs,'tabLEEUUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEEUAbs_min = min(dldata_LEEU);
dldata_LEEUAbs_max = max(dldata_LEEU);
dldata_LEEUAbs_range = dldata_LEEUAbs_max - dldata_LEEUAbs_min;
dlstripe_LEEUAbs_range = dldata_LEEUAbs_range/16;
dldata_LEEUAbs_mean = mean(dldata_LEEU);
dldata_LEEUAbs_median = median(dldata_LEEU);
%dldata_LEEUAbs_mode = mode(dldata_LEEU,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEEUAbs_std = std(dldata_LEEU);

tabdlLEEUAbs = table(categorical({'dldata_LEEUAbs_min';'dldata_LEEUAbs_max';'dldata_LEEUAbs_range';'dlstripe_LEEUAbs_range';'dldata_LEEUAbs_mean';'dldata_LEEUAbs_median'; 'dldata_LEEUAbs_std'}),{dldata_LEEUAbs_min; dldata_LEEUAbs_max; dldata_LEEUAbs_range; stripe_LEEUAbs_range; dldata_LEEUAbs_mean; dldata_LEEUAbs_median; dldata_LEEUAbs_std});
writetable(tabdlLEEUAbs,'tabdlLEEUUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the EU CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig141 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcEUMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in the EU per capita for 1990-2020');
title('EU');

saveas(gcf,'CO2EUpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2EUpcAbs.png')
saveas(gcf,'CO2EUpcAbs.epsc')

CO2EUpcAbs = imread('CO2EUpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig142 = figure
plot(ticksCO2,data_CO2pcEUMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('EU CO2 emissions pc, in metric tons')
title('EU CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcEUMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcEUMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcEUMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig143 = figure
plot(ticksdlCO2,dldata_CO2pcEUMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of EU CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of EU CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcEUMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcEUMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcEUMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig144 = figure
histogram(data_CO2pcEUMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('EU CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcEUMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcEUMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcEUMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig145 = figure
histogram(dldata_CO2pcEUMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of EU CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcEUMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcEUMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcEUMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcEUMetricTonsAbs_min = min(data_CO2pcEUMetricTons)
data_CO2pcEUMetricTonsAbs_max = max(data_CO2pcEUMetricTons)
data_CO2pcEUMetricTonsAbs_range = data_CO2pcEUMetricTonsAbs_max - data_CO2pcEUMetricTonsAbs_min
stripe_CO2pcEUMetricTonsAbs_range = data_CO2pcEUMetricTonsAbs_range/16
data_CO2pcEUMetricTonsAbs_mean = mean(data_CO2pcEUMetricTons)
data_CO2pcEUMetricTonsAbs_median = median(data_CO2pcEUMetricTons)
%data_CO2pcEUMetricTonsAbs_mode = mode(data_CO2pcEUMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcEUMetricTonsAbs = table(categorical({'data_CO2pcEUMetricTonsAbs_min';'data_CO2pcEUMetricTonsAbs_max';'data_CO2pcEUMetricTons_range';'stripe_CO2pcEUMetricTonsAbs_range';'data_CO2pcEUMetricTonsAbs_mean';'data_CO2pcEUMetricTonsAbs_median'}),{data_CO2pcEUMetricTonsAbs_min; data_CO2pcEUMetricTonsAbs_max; data_CO2pcEUMetricTonsAbs_range; stripe_CO2pcEUMetricTonsAbs_range; data_CO2pcEUMetricTonsAbs_mean; data_CO2pcEUMetricTonsAbs_median})
writetable(tabCO2pcEUMetricTonsAbs,'tabCO2pcEUMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcEUMetricTonsAbs_min = min(dldata_CO2pcEUMetricTons);
dldata_CO2pcEUMetricTonsAbs_max = max(dldata_CO2pcEUMetricTons);
dldata_CO2pcEUMetricTonsAbs_range = dldata_CO2pcEUMetricTonsAbs_max - dldata_CO2pcEUMetricTonsAbs_min;
dlstripe_CO2pcEUMetricTonsAbs_range = dldata_CO2pcEUMetricTonsAbs_range/16;
dldata_CO2pcEUMetricTonsAbs_mean = mean(dldata_CO2pcEUMetricTons);
dldata_CO2pcEUMetricTonsAbs_median = median(dldata_CO2pcEUMetricTons);
%dldata_CO2pcEUMetricTonsAbs_mode = mode(dldata_CO2pcEUMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcEUMetricTonsAbs_std = std(dldata_CO2pcEUMetricTons);

tabdlCO2pcEUMetricTonsAbs = table(categorical({'data_CO2pcEUMetricTonsAbs_min';'data_CO2pcEUMetricTonsAbs_max';'data_CO2pcEUMetricTons_range';'stripe_CO2pcEUMetricTonsAbs_range';'data_CO2pcEUMetricTonsAbs_mean';'data_CO2pcEUMetricTonsAbs_median'; 'dldata_CO2pcEUMetricTonsAbs_std'}),{data_CO2pcEUMetricTonsAbs_min; data_CO2pcEUMetricTonsAbs_max; data_CO2pcEUMetricTonsAbs_range; stripe_CO2pcEUMetricTonsAbs_range; data_CO2pcEUMetricTonsAbs_mean; data_CO2pcEUMetricTonsAbs_median; dldata_CO2pcEUMetricTonsAbs_std})
writetable(tabdlCO2pcEUMetricTonsAbs,'tabdlCO2pcEUMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the EU Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig146 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcEUDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('EU Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('EU');

saveas(gcf,'GreenProspDefLEPPPUSD2017EUpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017EUpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017EUpcAbs.epsc')

CO2EUpcAbs = imread('CO2EUpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig147 = figure
plot(ticksGreenProspLE,data_GreenProsppcEUDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('EU greening prosperity ratio pc (LE pc / CO2 pc)')
title('EU Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017EUpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017EUpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017EUpcAbs.epsc')

%% Plot - growth rates

fig148 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcEUDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of average EU greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of EU Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017EUpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017EUpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017EUpcAbs.epsc')


%% Histogram - absolute level

fig149 = figure
histogram(data_GreenProsppcEUDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('EU Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017EUpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017EUpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017EUpcAbs.epsc')

%% Histogram - growth rates

fig150 = figure
histogram(dldata_GreenProsppcEUDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of EU Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017EUAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017EUAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017EUAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcEUDefByLEAbs_min = min(data_GreenProsppcEUDefByLE);
data_GreenProsppcEUDefByLEAbs_max = max(data_GreenProsppcEUDefByLE);
data_GreenProsppcEUDefByLEAbs_range = data_GreenProsppcEUDefByLEAbs_max - data_GreenProsppcEUDefByLEAbs_min;
stripe_GreenProsppcEUDefByLEAbs_range = data_GreenProsppcEUDefByLEAbs_range/16;
data_GreenProsppcEUDefByLEAbs_mean = mean(data_GreenProsppcEUDefByLE);
data_GreenProsppcEUDefByLEAbs_median = median(data_GreenProsppcEUDefByLE);
%data_GreenProsppcEUDefByLEAbs_mode = mode(data_GreenProsppcEUDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcEUDefByLEAbs_std = std(data_GreenProsppcEUDefByLE);

tabGreenProsppcEUDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcEUDefByLEAbs_min';'data_GreenProsppcEUDefByLEAbs_max';'data_GreenProsppcEUDefByLE_range';'stripe_GreenProsppcEUDefByLEAbs_range';'data_GreenProsppcEUDefByLEAbs_mean';'data_GreenProsppcEUDefByLEAbs_median'; 'data_GreenProsppcEUDefByLEAbs_std'}),{data_GreenProsppcEUDefByLEAbs_min; data_GreenProsppcEUDefByLEAbs_max; data_GreenProsppcEUDefByLEAbs_range; stripe_GreenProsppcEUDefByLEAbs_range; data_GreenProsppcEUDefByLEAbs_mean; data_GreenProsppcEUDefByLEAbs_median; data_GreenProsppcEUDefByLEAbs_std});
writetable(tabGreenProsppcEUDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcEUDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcEUDefByLEAbs_min = min(dldata_GreenProsppcEUDefByLE);
dldata_GreenProsppcEUDefByLEAbs_max = max(dldata_GreenProsppcEUDefByLE);
dldata_GreenProsppcEUDefByLEAbs_range = dldata_GreenProsppcEUDefByLEAbs_max - dldata_GreenProsppcEUDefByLEAbs_min;
dlstripe_GreenProsppcEUDefByLEAbs_range = dldata_GreenProsppcEUDefByLEAbs_range/16;
dldata_GreenProsppcEUDefByLEAbs_mean = mean(dldata_GreenProsppcEUDefByLE);
dldata_GreenProsppcEUDefByLEAbs_median = median(dldata_GreenProsppcEUDefByLE);
%dldata_GreenProsppcEUDefByLEAbs_mode = mode(dldata_GreenProsppcEUDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcEUDefByLEAbs_std = std(dldata_GreenProsppcEUDefByLE);

tabdlGreenProsppcEUDefByLEAbs = table(categorical({'dldata_GreenProsppcEUDefByLEAbs_min';'dldata_GreenProsppcEUDefByLEAbs_max';'dldata_GreenProsppcEUDefByLE_range';'dlstripe_GreenProsppcEUDefByLEAbs_range';'dldata_GreenProsppcEUDefByLEAbs_mean'; 'dldata_GreenProsppcEUDefByLEAbs_median';'dldata_GreenProsppcEUDefByLEAbs_std'}),{dldata_GreenProsppcEUDefByLEAbs_min; dldata_GreenProsppcEUDefByLEAbs_max; dldata_GreenProsppcEUDefByLEAbs_range; dlstripe_GreenProsppcEUDefByLEAbs_range; dldata_GreenProsppcEUDefByLEAbs_mean; dldata_GreenProsppcEUDefByLEAbs_median; dldata_GreenProsppcEUDefByLEAbs_std});
writetable(tabdlGreenProsppcEUDefByLEAbs ,'tabdlGreenProsppcEUDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% India - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEIND = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI114:BM114');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEIND = log(data_LEIND);
dldata_LEIND = diff(ldata_LEIND)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcINDMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI114:BM114');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcINDMetricTons = log(data_CO2pcINDMetricTons);
dldata_CO2pcINDMetricTons = diff(ldata_CO2pcINDMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcINDDefByLE = data_LEIND ./ data_CO2pcINDMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcINDDefByLE = log(data_GreenProsppcINDDefByLE);
dldata_GreenProsppcINDDefByLE = diff(ldata_GreenProsppcINDDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the IND LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig151 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEIND)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('India LE per capita in PPP International USD of 2017 for 1990-1990');
title('India');

saveas(gcf,'LEINDpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEINDpcAbs.png')
saveas(gcf,'LEINDpcAbs.epsc')

LEINDpcDev = imread('LEINDpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig152 = figure
plot(ticksLE,data_LEIND,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('India LE per capita in PPP international USD of 2017')
title('India LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEINDAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEINDAbsSince1990Annual.png')
saveas(gcf,'Plot_LEINDAbsSince1990Annual.epsc')


%% Plot - growth rates

fig153 = figure
plot(ticksdlLE,dldata_LEIND,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of India LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of India LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEINDAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEINDAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEINDAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig154 = figure
histogram(data_LEIND,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('India LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEINDAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEINDAbsSince1990Annual.png')
saveas(gcf,'Hist_LEINDAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig155 = figure
histogram(dldata_LEIND,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of India LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEINDAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEINDAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEINDAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEINDAbs_min = min(data_LEIND)
data_LEINDAbs_max = max(data_LEIND)
data_LEINDAbs_range = data_LEINDAbs_max - data_LEINDAbs_min
stripe_LEINDAbs_range = data_LEINDAbs_range/16
data_LEINDAbs_mean = mean(data_LEIND)
data_LEINDAbs_median = median(data_LEIND)
%data_LEINDAbs_mode = mode(data_LEIND,'all') %AM230708 Sth's wrong about the mode command?!

tabLEINDAbs = table(categorical({'data_LEINDAbs_min';'data_LEINDAbs_max';'data_LEINDAbs_range';'stripe_LEINDAbs_range';'data_LEINDAbs_mean';'data_LEINDAbs_median'}),{data_LEINDAbs_min; data_LEINDAbs_max; data_LEINDAbs_range; stripe_LEINDAbs_range; data_LEINDAbs_mean; data_LEINDAbs_median})
writetable(tabLEINDAbs,'tabLEINDUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEINDAbs_min = min(dldata_LEIND);
dldata_LEINDAbs_max = max(dldata_LEIND);
dldata_LEINDAbs_range = dldata_LEINDAbs_max - dldata_LEINDAbs_min;
dlstripe_LEINDAbs_range = dldata_LEINDAbs_range/16;
dldata_LEINDAbs_mean = mean(dldata_LEIND);
dldata_LEINDAbs_median = median(dldata_LEIND);
%dldata_LEINDAbs_mode = mode(dldata_LEIND,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEINDAbs_std = std(dldata_LEIND);

tabdlLEINDAbs = table(categorical({'dldata_LEINDAbs_min';'dldata_LEINDAbs_max';'dldata_LEINDAbs_range';'dlstripe_LEINDAbs_range';'dldata_LEINDAbs_mean';'dldata_LEINDAbs_median'; 'dldata_LEINDAbs_std'}),{dldata_LEINDAbs_min; dldata_LEINDAbs_max; dldata_LEINDAbs_range; stripe_LEINDAbs_range; dldata_LEINDAbs_mean; dldata_LEINDAbs_median; dldata_LEINDAbs_std});
writetable(tabdlLEINDAbs,'tabdlLEINDUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the IND CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig156 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcINDMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in India per capita for 1990-2020');
title('India');

saveas(gcf,'CO2INDpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2INDpcAbs.png')
saveas(gcf,'CO2INDpcAbs.epsc')

CO2INDpcAbs = imread('CO2INDpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig157 = figure
plot(ticksCO2,data_CO2pcINDMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('India CO2 emissions pc, in metric tons')
title('India CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcINDMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcINDMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcINDMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig158 = figure
plot(ticksdlCO2,dldata_CO2pcINDMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of India CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of India CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcINDMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcINDMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcINDMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig159 = figure
histogram(data_CO2pcINDMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('India CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcINDMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcINDMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcINDMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig160 = figure
histogram(dldata_CO2pcINDMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of India CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcINDMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcINDMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcINDMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcINDMetricTonsAbs_min = min(data_CO2pcINDMetricTons)
data_CO2pcINDMetricTonsAbs_max = max(data_CO2pcINDMetricTons)
data_CO2pcINDMetricTonsAbs_range = data_CO2pcINDMetricTonsAbs_max - data_CO2pcINDMetricTonsAbs_min
stripe_CO2pcINDMetricTonsAbs_range = data_CO2pcINDMetricTonsAbs_range/16
data_CO2pcINDMetricTonsAbs_mean = mean(data_CO2pcINDMetricTons)
data_CO2pcINDMetricTonsAbs_median = median(data_CO2pcINDMetricTons)
%data_CO2pcINDMetricTonsAbs_mode = mode(data_CO2pcINDMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcINDMetricTonsAbs = table(categorical({'data_CO2pcINDMetricTonsAbs_min';'data_CO2pcINDMetricTonsAbs_max';'data_CO2pcINDMetricTons_range';'stripe_CO2pcINDMetricTonsAbs_range';'data_CO2pcINDMetricTonsAbs_mean';'data_CO2pcINDMetricTonsAbs_median'}),{data_CO2pcINDMetricTonsAbs_min; data_CO2pcINDMetricTonsAbs_max; data_CO2pcINDMetricTonsAbs_range; stripe_CO2pcINDMetricTonsAbs_range; data_CO2pcINDMetricTonsAbs_mean; data_CO2pcINDMetricTonsAbs_median})
writetable(tabCO2pcINDMetricTonsAbs,'tabCO2pcINDMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcINDMetricTonsAbs_min = min(dldata_CO2pcINDMetricTons);
dldata_CO2pcINDMetricTonsAbs_max = max(dldata_CO2pcINDMetricTons);
dldata_CO2pcINDMetricTonsAbs_range = dldata_CO2pcINDMetricTonsAbs_max - dldata_CO2pcINDMetricTonsAbs_min;
dlstripe_CO2pcINDMetricTonsAbs_range = dldata_CO2pcINDMetricTonsAbs_range/16;
dldata_CO2pcINDMetricTonsAbs_mean = mean(dldata_CO2pcINDMetricTons);
dldata_CO2pcINDMetricTonsAbs_median = median(dldata_CO2pcINDMetricTons);
%dldata_CO2pcINDMetricTonsAbs_mode = mode(dldata_CO2pcINDMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcINDMetricTonsAbs_std = std(dldata_CO2pcINDMetricTons);

tabdlCO2pcINDMetricTonsAbs = table(categorical({'data_CO2pcINDMetricTonsAbs_min';'data_CO2pcINDMetricTonsAbs_max';'data_CO2pcINDMetricTons_range';'stripe_CO2pcINDMetricTonsAbs_range';'data_CO2pcINDMetricTonsAbs_mean';'data_CO2pcINDMetricTonsAbs_median'; 'dldata_CO2pcINDMetricTonsAbs_std'}),{data_CO2pcINDMetricTonsAbs_min; data_CO2pcINDMetricTonsAbs_max; data_CO2pcINDMetricTonsAbs_range; stripe_CO2pcINDMetricTonsAbs_range; data_CO2pcINDMetricTonsAbs_mean; data_CO2pcINDMetricTonsAbs_median; dldata_CO2pcINDMetricTonsAbs_std})
writetable(tabdlCO2pcINDMetricTonsAbs,'tabdlCO2pcINDMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the IND Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig161 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcINDDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('India Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020');
title('India');

saveas(gcf,'GreenProspDefLEPPPUSD2017INDpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017INDpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017INDpcAbs.epsc')

CO2INDpcAbs = imread('CO2INDpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig162 = figure
plot(ticksGreenProspLE,data_GreenProsppcINDDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('India greening prosperity ratio pc (LE pc / CO2 pc)')
title('India Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017INDpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017INDpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017INDpcAbs.epsc')

%% Plot - growth rates

fig163 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcINDDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of India greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of India Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017INDpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017INDpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017INDpcAbs.epsc')


%% Histogram - absolute level

fig164 = figure
histogram(data_GreenProsppcINDDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('India Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017INDpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017INDpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017INDpcAbs.epsc')

%% Histogram - growth rates

fig165 = figure
histogram(dldata_GreenProsppcINDDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of India Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017INDAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017INDAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017INDAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcINDDefByLEAbs_min = min(data_GreenProsppcINDDefByLE);
data_GreenProsppcINDDefByLEAbs_max = max(data_GreenProsppcINDDefByLE);
data_GreenProsppcINDDefByLEAbs_range = data_GreenProsppcINDDefByLEAbs_max - data_GreenProsppcINDDefByLEAbs_min;
stripe_GreenProsppcINDDefByLEAbs_range = data_GreenProsppcINDDefByLEAbs_range/16;
data_GreenProsppcINDDefByLEAbs_mean = mean(data_GreenProsppcINDDefByLE);
data_GreenProsppcINDDefByLEAbs_median = median(data_GreenProsppcINDDefByLE);
%data_GreenProsppcINDDefByLEAbs_mode = mode(data_GreenProsppcINDDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcINDDefByLEAbs_std = std(data_GreenProsppcINDDefByLE);

tabGreenProsppcINDDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcINDDefByLEAbs_min';'data_GreenProsppcINDDefByLEAbs_max';'data_GreenProsppcINDDefByLE_range';'stripe_GreenProsppcINDDefByLEAbs_range';'data_GreenProsppcINDDefByLEAbs_mean';'data_GreenProsppcINDDefByLEAbs_median'; 'data_GreenProsppcINDDefByLEAbs_std'}),{data_GreenProsppcINDDefByLEAbs_min; data_GreenProsppcINDDefByLEAbs_max; data_GreenProsppcINDDefByLEAbs_range; stripe_GreenProsppcINDDefByLEAbs_range; data_GreenProsppcINDDefByLEAbs_mean; data_GreenProsppcINDDefByLEAbs_median; data_GreenProsppcINDDefByLEAbs_std});
writetable(tabGreenProsppcINDDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcINDDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcINDDefByLEAbs_min = min(dldata_GreenProsppcINDDefByLE);
dldata_GreenProsppcINDDefByLEAbs_max = max(dldata_GreenProsppcINDDefByLE);
dldata_GreenProsppcINDDefByLEAbs_range = dldata_GreenProsppcINDDefByLEAbs_max - dldata_GreenProsppcINDDefByLEAbs_min;
dlstripe_GreenProsppcINDDefByLEAbs_range = dldata_GreenProsppcINDDefByLEAbs_range/16;
dldata_GreenProsppcINDDefByLEAbs_mean = mean(dldata_GreenProsppcINDDefByLE);
dldata_GreenProsppcINDDefByLEAbs_median = median(dldata_GreenProsppcINDDefByLE);
%dldata_GreenProsppcINDDefByLEAbs_mode = mode(dldata_GreenProsppcINDDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcINDDefByLEAbs_std = std(dldata_GreenProsppcINDDefByLE);

tabdlGreenProsppcINDDefByLEAbs = table(categorical({'dldata_GreenProsppcINDDefByLEAbs_min';'dldata_GreenProsppcINDDefByLEAbs_max';'dldata_GreenProsppcINDDefByLE_range';'dlstripe_GreenProsppcINDDefByLEAbs_range';'dldata_GreenProsppcINDDefByLEAbs_mean'; 'dldata_GreenProsppcINDDefByLEAbs_median';'dldata_GreenProsppcINDDefByLEAbs_std'}),{dldata_GreenProsppcINDDefByLEAbs_min; dldata_GreenProsppcINDDefByLEAbs_max; dldata_GreenProsppcINDDefByLEAbs_range; dlstripe_GreenProsppcINDDefByLEAbs_range; dldata_GreenProsppcINDDefByLEAbs_mean; dldata_GreenProsppcINDDefByLEAbs_median; dldata_GreenProsppcINDDefByLEAbs_std});
writetable(tabdlGreenProsppcINDDefByLEAbs ,'tabdlGreenProsppcINDDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Japan - Loading the Dataset and Defining the Time Interval

% NB: Read data from an *.xlsx source file (!!! To work in Mac OS, needs to be saved as *.xlsx if provided in *.xls or *csv formats!)

% LE pc in PPP international USD of 2017 - data download source: https://data.worldbank.org/indicator/API_NY.LE.PCAP.PP.KD
data_LEJPN = xlsread('API_NY.LE.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx','Data','AI124:BM124');
ticksLE = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data)!
ldata_LEJPN = log(data_LEJPN);
dldata_LEJPN = diff(ldata_LEJPN)*100;
ticksdlLE = 1991:2020;

% CO2 emisions, metric ton per capita - data download source: https://data.worldbank.org/indicator/EN.ATM.CO2E.PC
data_CO2pcJPNMetricTons = xlsread('API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx','Data','AI124:BM124');
ticksCO2 = 1990:2020; %AM231005 Select the date range, i.e., data vector, to be displayed (NO earlier data again: but symmetry)!
ldata_CO2pcJPNMetricTons = log(data_CO2pcJPNMetricTons);
dldata_CO2pcJPNMetricTons = diff(ldata_CO2pcJPNMetricTons)*100;
ticksdlCO2 = 1991:2020;

% LE pc (in PPP Intl USD of 2017) normalized by CO2 pc emitions (in metric tons): dividing the 1st series to the 2nd above 
data_GreenProsppcJPNDefByLE = data_LEJPN ./ data_CO2pcJPNMetricTons;
ticksGreenProspLE = 1990:2020 % AM231005 Keep the name/label "ticks" becuase it is used/called below in generating the graphs!
ldata_GreenProsppcJPNDefByLE = log(data_GreenProsppcJPNDefByLE);
dldata_GreenProsppcJPNDefByLE = diff(ldata_GreenProsppcJPNDefByLE)*100;
ticksdlGreenProspLE = 1991:2020;

%% Creating the JPN LE pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above (e.g., running from 1960 to 2022), rotate the tick labels of the
% x-axis by 90 degrees, and display annual tick labels. We also hide the tick labels of the y-axis. Then use imagesc
% to display the stripes and the colormap wscolors.

fig166 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEJPN)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
fontsize(16,"points")
%title('Japan LE per capita in PPP International USD of 2017 for 1990-1990');
title('Japan');

saveas(gcf,'LEJPNpcAbs.fig') %AM230701 checking online
saveas(gcf,'LEJPNpcAbs.png')
saveas(gcf,'LEJPNpcAbs.epsc')

LEJPNpcDev = imread('LEJPNpcAbs.png'); %AM230701 after checking online


%% Plot - absolute level

fig167 = figure
plot(ticksLE,data_LEJPN,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Japan LE per capita in PPP international USD of 2017')
title('Japan LE per capita in PPP international USD of 2017');

saveas(gcf,'Plot_LEJPNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_LEJPNAbsSince1990Annual.png')
saveas(gcf,'Plot_LEJPNAbsSince1990Annual.epsc')


%% Plot - growth rates

fig168 = figure
plot(ticksdlLE,dldata_LEJPN,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates of Japan LE per capita in PPP international USD of 2017, % pa')
title('Growth Rates of Japan LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Plot_dlLEJPNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlLEJPNAbsSince1990Annual.png')
saveas(gcf,'Plot_dlLEJPNAbsSince1990Annual.epsc')


%% Histogram - absolute level

fig169 = figure
histogram(data_LEJPN,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Japan LE per capita in PPP international USD of 2017');

saveas(gcf,'Hist_LEJPNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_LEJPNAbsSince1990Annual.png')
saveas(gcf,'Hist_LEJPNAbsSince1990Annual.epsc')

%% Histogram - growth rates

fig170 = figure
histogram(dldata_LEJPN,16)
%axis ([1850 2023 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates of Japan LE per capita in PPP international USD of 2017, % pa');

saveas(gcf,'Hist_dlLEJPNAbsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlLEJPNAbsSince1990Annual.png')
saveas(gcf,'Hist_dlLEJPNAbsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_LEJPNAbs_min = min(data_LEJPN)
data_LEJPNAbs_max = max(data_LEJPN)
data_LEJPNAbs_range = data_LEJPNAbs_max - data_LEJPNAbs_min
stripe_LEJPNAbs_range = data_LEJPNAbs_range/16
data_LEJPNAbs_mean = mean(data_LEJPN)
data_LEJPNAbs_median = median(data_LEJPN)
%data_LEJPNAbs_mode = mode(data_LEJPN,'all') %AM230708 Sth's wrong about the mode command?!

tabLEJPNAbs = table(categorical({'data_LEJPNAbs_min';'data_LEJPNAbs_max';'data_LEJPNAbs_range';'stripe_LEJPNAbs_range';'data_LEJPNAbs_mean';'data_LEJPNAbs_median'}),{data_LEJPNAbs_min; data_LEJPNAbs_max; data_LEJPNAbs_range; stripe_LEJPNAbs_range; data_LEJPNAbs_mean; data_LEJPNAbs_median})
writetable(tabLEJPNAbs,'tabLEJPNUSDPPPof2017Abs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_LEJPNAbs_min = min(dldata_LEJPN);
dldata_LEJPNAbs_max = max(dldata_LEJPN);
dldata_LEJPNAbs_range = dldata_LEJPNAbs_max - dldata_LEJPNAbs_min;
dlstripe_LEJPNAbs_range = dldata_LEJPNAbs_range/16;
dldata_LEJPNAbs_mean = mean(dldata_LEJPN);
dldata_LEJPNAbs_median = median(dldata_LEJPN);
%dldata_LEJPNAbs_mode = mode(dldata_LEJPN,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_LEJPNAbs_std = std(dldata_LEJPN);

tabdlLEJPNAbs = table(categorical({'dldata_LEJPNAbs_min';'dldata_LEJPNAbs_max';'dldata_LEJPNAbs_range';'dlstripe_LEJPNAbs_range';'dldata_LEJPNAbs_mean';'dldata_LEJPNAbs_median'; 'dldata_LEJPNAbs_std'}),{dldata_LEJPNAbs_min; dldata_LEJPNAbs_max; dldata_LEJPNAbs_range; stripe_LEJPNAbs_range; dldata_LEJPNAbs_mean; dldata_LEJPNAbs_median; dldata_LEJPNAbs_std});
writetable(tabdlLEJPNAbs,'tabdlLEJPNUSDPPPof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM230720 adding CO2 pc (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Creating the JPN CO2 pc Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig171 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksCO2) max(ticksCO2)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksCO2,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksCO2',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_CO2pcJPNMetricTons)    %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_AMGreening_GreenToBrown)
colorbar
fontsize(16,"points")
%title('CO2 Emissions in the Japan per capita for 1990-2020');
title('Japan');

saveas(gcf,'CO2JPNpcAbs.fig') %AM230701 checking online
saveas(gcf,'CO2JPNpcAbs.png')
saveas(gcf,'CO2JPNpcAbs.epsc')

CO2JPNpcAbs = imread('CO2JPNpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig172 = figure
plot(ticksCO2,data_CO2pcJPNMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('JPN CO2 emissions pc, in metric tons')
title('JPN CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_CO2pcJPNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_CO2pcJPNMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_CO2pcJPNMetricTonsSince1990Annual.epsc')

%% Plot - growth rates

fig173 = figure
plot(ticksdlCO2,dldata_CO2pcJPNMetricTons,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates, in % pa, of Japan CO2 emissions pc, in metric tons')
title('Growth Rates, in % pa, of Japan CO2 Emissions per capita, in Metric Tons');

saveas(gcf,'Plot_dlCO2pcJPNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Plot_dlCO2pcJPNMetricTonsSince1990Annual.png')
saveas(gcf,'Plot_dlCO2pcJPNMetricTonsSince1990Annual.epsc')

%% Histogram - absolute level

fig174 = figure
histogram(data_CO2pcJPNMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Japan CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_CO2pcJPNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_CO2pcJPNMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_CO2pcJPNMetricTonsSince1990Annual.epsc')

%% Histogram - growth rates

fig175 = figure
histogram(dldata_CO2pcJPNMetricTons,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates, in % pa, of Japan CO2 Emissions per capita, in metric tons');

saveas(gcf,'Hist_dlCO2pcJPNMetricTonsSince1990Annual.fig') %AM230701 checking online
saveas(gcf,'Hist_dlCO2pcJPNMetricTonsSince1990Annual.png')
saveas(gcf,'Hist_dlCO2pcJPNMetricTonsSince1990Annual.epsc')


%% Computation and Export of a Descriptive Stats Table - absolute level

data_CO2pcJPNMetricTonsAbs_min = min(data_CO2pcJPNMetricTons)
data_CO2pcJPNMetricTonsAbs_max = max(data_CO2pcJPNMetricTons)
data_CO2pcJPNMetricTonsAbs_range = data_CO2pcJPNMetricTonsAbs_max - data_CO2pcJPNMetricTonsAbs_min
stripe_CO2pcJPNMetricTonsAbs_range = data_CO2pcJPNMetricTonsAbs_range/16
data_CO2pcJPNMetricTonsAbs_mean = mean(data_CO2pcJPNMetricTons)
data_CO2pcJPNMetricTonsAbs_median = median(data_CO2pcJPNMetricTons)
%data_CO2pcJPNMetricTonsAbs_mode = mode(data_CO2pcJPNMetricTons,'all') %AM230708 Sth's wrong about the mode command?!

tabCO2pcJPNMetricTonsAbs = table(categorical({'data_CO2pcJPNMetricTonsAbs_min';'data_CO2pcJPNMetricTonsAbs_max';'data_CO2pcJPNMetricTons_range';'stripe_CO2pcJPNMetricTonsAbs_range';'data_CO2pcJPNMetricTonsAbs_mean';'data_CO2pcJPNMetricTonsAbs_median'}),{data_CO2pcJPNMetricTonsAbs_min; data_CO2pcJPNMetricTonsAbs_max; data_CO2pcJPNMetricTonsAbs_range; stripe_CO2pcJPNMetricTonsAbs_range; data_CO2pcJPNMetricTonsAbs_mean; data_CO2pcJPNMetricTonsAbs_median})
writetable(tabCO2pcJPNMetricTonsAbs,'tabCO2pcJPNMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//ProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_CO2pcJPNMetricTonsAbs_min = min(dldata_CO2pcJPNMetricTons);
dldata_CO2pcJPNMetricTonsAbs_max = max(dldata_CO2pcJPNMetricTons);
dldata_CO2pcJPNMetricTonsAbs_range = dldata_CO2pcJPNMetricTonsAbs_max - dldata_CO2pcJPNMetricTonsAbs_min;
dlstripe_CO2pcJPNMetricTonsAbs_range = dldata_CO2pcJPNMetricTonsAbs_range/16;
dldata_CO2pcJPNMetricTonsAbs_mean = mean(dldata_CO2pcJPNMetricTons);
dldata_CO2pcJPNMetricTonsAbs_median = median(dldata_CO2pcJPNMetricTons);
%dldata_CO2pcJPNMetricTonsAbs_mode = mode(dldata_CO2pcJPNMetricTons,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_CO2pcJPNMetricTonsAbs_std = std(dldata_CO2pcJPNMetricTons);

tabdlCO2pcJPNMetricTonsAbs = table(categorical({'data_CO2pcJPNMetricTonsAbs_min';'data_CO2pcJPNMetricTonsAbs_max';'data_CO2pcJPNMetricTons_range';'stripe_CO2pcJPNMetricTonsAbs_range';'data_CO2pcJPNMetricTonsAbs_mean';'data_CO2pcJPNMetricTonsAbs_median'; 'dldata_CO2pcJPNMetricTonsAbs_std'}),{data_CO2pcJPNMetricTonsAbs_min; data_CO2pcJPNMetricTonsAbs_max; data_CO2pcJPNMetricTonsAbs_range; stripe_CO2pcJPNMetricTonsAbs_range; data_CO2pcJPNMetricTonsAbs_mean; data_CO2pcJPNMetricTonsAbs_median; dldata_CO2pcJPNMetricTonsAbs_std})
writetable(tabdlCO2pcJPNMetricTonsAbs,'tabdlCO2pcJPNMetricTonsAbs.xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231005 adding the greening prosperity (ratio) stripes = CO2 pc / LE pc at PPP intl USD of 2017 (World Bank data) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Creating the JPN Greening Prosperity (Ratio) Figures

% To create the graphics, we use imagesc (below). We first create a landscape Figure Window with white background. We
% then create axes with the time axes as defined above in ticksCO2 using min() and max() (i.e., now running from 1990
% to 2020), rotate the tick labels of the x-axis by 90 degrees, and display annual tick labels. We also hide the tick
% labels of the y-axis. Then use imagesc to display the CO2 emissions stripes and the colormap wscolors_AMCO2WpcEmissions.

fig176 = figure('Position',[100 100 800 300],...
   'Color',[1 1 1])
axes(...
   'XLim',[min(ticksGreenProspLE) max(ticksGreenProspLE)],... %AM230720 Select the relevant x-axis ticks variable name/length
   'XTickMode','manual',...
   'XTick',ticksGreenProspLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksGreenProspLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the data) to be displayed!
   'CData',data_GreenProsppcJPNDefByLE)    %AM230630 Select the data vector to be displayed!
colormap(wscolors_AMGreening_BrownToGreen)
colorbar
fontsize(16,"points")
%title('Japan Greening Prosperity (Ratio, with LE in the numerator) Stripes per capita for 1990-2020 ');
title('Japan');

saveas(gcf,'GreenProspDefLEPPPUSD2017JPNpcAbs.fig') %AM230701 checking online
saveas(gcf,'GreenProspDefLEPPPUSD2017JPNpcAbs.png')
saveas(gcf,'GreenProspDefLEPPPUSD2017JPNpcAbs.epsc')

CO2JPNpcAbs = imread('CO2JPNpcAbs.png'); %AM230701 checking online

%% Plot - absolute level

fig177 = figure
plot(ticksGreenProspLE,data_GreenProsppcJPNDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(12,"points")
grid on
xlabel('years (sample 1990-2020)')
ylabel('Japan greening prosperity ratio pc (LE pc / CO2 pc)')
title('Japan Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017JPNpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017JPNpcAbs.png')
saveas(gcf,'Plot_GreenProspDefLEPPPUSD2017JPNpcAbs.epsc')

%% Plot - growth rates

fig178 = figure
plot(ticksdlGreenProspLE,dldata_GreenProsppcJPNDefByLE,'LineWidth',2)
axis ([1990 2020 -20 20])
fontsize(12,"points")
grid on
xlabel('years (sample 1991-2020)')
ylabel('growth rates (in % pa) of Japan greening prosperity ratio pc (LE pc / CO2 pc)')
title('Growth Rates (in % pa) of Japan Greening Prosperity Ratio pc (LE pc / CO2 pc)');

saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017JPNpcAbs.fig') %AM230701 checking online
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017JPNpcAbs.png')
saveas(gcf,'Plot_dlGreenProspDefLEPPPUSD2017JPNpcAbs.epsc')


%% Histogram - absolute level

fig179 = figure
histogram(data_GreenProsppcJPNDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Japan Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017JPNpcAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017JPNpcAbs.png')
saveas(gcf,'Hist_GreenProspDefLEPPPUSD2017JPNpcAbs.epsc')

%% Histogram - growth rates

fig180 = figure
histogram(dldata_GreenProsppcJPNDefByLE,16)
%axis ([1990 2020 -0.6 +1.0])
fontsize(12,"points")
xlabel('')
ylabel('frequency')
title('Growth Rates (in % pa) of Japan Greening Prosperity Ratio (LE pc / CO2 pc) per capita');

saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017JPNAbs.fig') %AM230701 checking online
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017JPNAbs.png')
saveas(gcf,'Hist_dlGreenProspDefLEPPPUSD2017JPNAbs.epsc')

%% Computation and Export of a Descriptive Stats Table - absolute level

data_GreenProsppcJPNDefByLEAbs_min = min(data_GreenProsppcJPNDefByLE);
data_GreenProsppcJPNDefByLEAbs_max = max(data_GreenProsppcJPNDefByLE);
data_GreenProsppcJPNDefByLEAbs_range = data_GreenProsppcJPNDefByLEAbs_max - data_GreenProsppcJPNDefByLEAbs_min;
stripe_GreenProsppcJPNDefByLEAbs_range = data_GreenProsppcJPNDefByLEAbs_range/16;
data_GreenProsppcJPNDefByLEAbs_mean = mean(data_GreenProsppcJPNDefByLE);
data_GreenProsppcJPNDefByLEAbs_median = median(data_GreenProsppcJPNDefByLE);
%data_GreenProsppcJPNDefByLEAbs_mode = mode(data_GreenProsppcJPNDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
data_GreenProsppcJPNDefByLEAbs_std = std(data_GreenProsppcJPNDefByLE);

tabGreenProsppcJPNDefByLEPPPIntUSDof2017Abs = table(categorical({'data_GreenProsppcJPNDefByLEAbs_min';'data_GreenProsppcJPNDefByLEAbs_max';'data_GreenProsppcJPNDefByLE_range';'stripe_GreenProsppcJPNDefByLEAbs_range';'data_GreenProsppcJPNDefByLEAbs_mean';'data_GreenProsppcJPNDefByLEAbs_median'; 'data_GreenProsppcJPNDefByLEAbs_std'}),{data_GreenProsppcJPNDefByLEAbs_min; data_GreenProsppcJPNDefByLEAbs_max; data_GreenProsppcJPNDefByLEAbs_range; stripe_GreenProsppcJPNDefByLEAbs_range; data_GreenProsppcJPNDefByLEAbs_mean; data_GreenProsppcJPNDefByLEAbs_median; data_GreenProsppcJPNDefByLEAbs_std});
writetable(tabGreenProsppcJPNDefByLEPPPIntUSDof2017Abs ,'tabGreenProsppcJPNDefByLEPPPIntUSDof2017Abs.xlsx');
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")

%% Computation and Export of a Descriptive Stats Table - growth rates

dldata_GreenProsppcJPNDefByLEAbs_min = min(dldata_GreenProsppcJPNDefByLE);
dldata_GreenProsppcJPNDefByLEAbs_max = max(dldata_GreenProsppcJPNDefByLE);
dldata_GreenProsppcJPNDefByLEAbs_range = dldata_GreenProsppcJPNDefByLEAbs_max - dldata_GreenProsppcJPNDefByLEAbs_min;
dlstripe_GreenProsppcJPNDefByLEAbs_range = dldata_GreenProsppcJPNDefByLEAbs_range/16;
dldata_GreenProsppcJPNDefByLEAbs_mean = mean(dldata_GreenProsppcJPNDefByLE);
dldata_GreenProsppcJPNDefByLEAbs_median = median(dldata_GreenProsppcJPNDefByLE);
%dldata_GreenProsppcJPNDefByLEAbs_mode = mode(dldata_GreenProsppcJPNDefByLE,'all'); %AM230708 Sth's wrong about the mode command?!
dldata_GreenProsppcJPNDefByLEAbs_std = std(dldata_GreenProsppcJPNDefByLE);

tabdlGreenProsppcJPNDefByLEAbs = table(categorical({'dldata_GreenProsppcJPNDefByLEAbs_min';'dldata_GreenProsppcJPNDefByLEAbs_max';'dldata_GreenProsppcJPNDefByLE_range';'dlstripe_GreenProsppcJPNDefByLEAbs_range';'dldata_GreenProsppcJPNDefByLEAbs_mean'; 'dldata_GreenProsppcJPNDefByLEAbs_median';'dldata_GreenProsppcJPNDefByLEAbs_std'}),{dldata_GreenProsppcJPNDefByLEAbs_min; dldata_GreenProsppcJPNDefByLEAbs_max; dldata_GreenProsppcJPNDefByLEAbs_range; dlstripe_GreenProsppcJPNDefByLEAbs_range; dldata_GreenProsppcJPNDefByLEAbs_mean; dldata_GreenProsppcJPNDefByLEAbs_median; dldata_GreenProsppcJPNDefByLEAbs_std});
writetable(tabdlGreenProsppcJPNDefByLEAbs ,'tabdlGreenProsppcJPNDefByLEAbs .xlsx')
%path = export(table,"//Users//alexandermihailov//Desktop//tempwork//GreeningProsperityStripes",Format="tex")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AM231006 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% MULTIPLOT FIGURES %%%

fig181 = figure

subplot(3,4,1)
plot(ticksLE,data_LEWorld,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average world LE per capita in PPP international USD of 2017')
title('World');

subplot(3,4,2)
plot(ticksLE,data_LEHiIncCs,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average HiIncCs LE per capita in PPP international USD of 2017')
title('High-Income Countries')

subplot(3,4,3)
plot(ticksLE,data_LELoIncCs,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average LoIncCs LE per capita in PPP international USD of 2017')
title('Low-Income Countries')

subplot(3,4,4)
plot(ticksLE,data_LEUS,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('USLE per capita in PPP international USD of 2017')
title('US');

subplot(3,4,5)
plot(ticksLE,data_LEUK,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('UK LE per capita in PPP international USD of 2017')
title('UK');

subplot(3,4,6)
plot(ticksLE,data_LEEU,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('EU LE per capita in PPP international USD of 2017')
title('EU');

subplot(3,4,7)
plot(ticksLE,data_LEAUS,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('AUS LE per capita in PPP international USD of 2017')
title('Australia');

subplot(3,4,8)
plot(ticksLE,data_LEJPN,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('JAP LE per capita in PPP international USD of 2017')
title('Japan');

subplot(3,4,9)
plot(ticksLE,data_LECHN,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('CHN LE per capita in PPP international USD of 2017')
title('China');

subplot(3,4,10)
plot(ticksLE,data_LEIND,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('IND LE per capita in PPP international USD of 2017')
title('India');

subplot(3,4,11)
plot(ticksLE,data_LEBRA,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('BRA LE per capita in PPP international USD of 2017')
title('Brazil');

subplot(3,4,12)
plot(ticksLE,data_LEMOZ,'LineWidth',2)
axis ([1990 2020 0 65000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('MOZ LE per capita in PPP international USD of 2017')
title('Mozambique');

saveas(gcf,'MultiPlot12_LEPPPUSDof2017.fig')
saveas(gcf,'MultiPlot12_LEPPPUSDof2017.png')
saveas(gcf,'MultiPlot12_LEPPPUSDof2017.epsc')


%%%%%%%%%%%%%%%%%%%%%%%


fig182 = figure

subplot(3,4,1)
plot(ticksdlLE,dldata_LEWorld,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average world LE per capita in PPP international USD of 2017')
title('World');

subplot(3,4,2)
plot(ticksdlLE,dldata_LEHiIncCs,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('Average HiIncCs LE per capita in PPP international USD of 2017')
title('High-Income Css')

subplot(3,4,3)
plot(ticksdlLE,dldata_LELoIncCs,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('Average LoIncCs LE per capita in PPP international USD of 2017')
title('Low-Income Cs')

subplot(3,4,4)
plot(ticksdlLE,dldata_LEUS,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('US LE per capita in PPP international USD of 2017')
title('US');

subplot(3,4,5)
plot(ticksdlLE,dldata_LEUK,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('UK LE per capita in PPP international USD of 2017')
title('UK');

subplot(3,4,6)
plot(ticksdlLE,dldata_LEEU,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('EU LE per capita in PPP international USD of 2017')
title('EU');

subplot(3,4,7)
plot(ticksdlLE,dldata_LEAUS,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('AUS LE per capita in PPP international USD of 2017')
title('Australia');

subplot(3,4,8)
plot(ticksdlLE,dldata_LEJPN,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('JAP LE per capita in PPP international USD of 2017')
title('Japan');

subplot(3,4,9)
plot(ticksdlLE,dldata_LECHN,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('CHN LE per capita in PPP international USD of 2017')
title('China');

subplot(3,4,10)
plot(ticksdlLE,dldata_LEIND,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('IND LE per capita in PPP international USD of 2017')
title('India');

subplot(3,4,11)
plot(ticksdlLE,dldata_LEBRA,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('BRA LE per capita in PPP international USD of 2017')
title('Brazil');

subplot(3,4,12)
plot(ticksdlLE,dldata_LEMOZ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('MOZ LE per capita in PPP international USD of 2017')
title('Mozambique');

saveas(gcf,'MultiPlot12_dlLEPPPUSDof2017.fig')
saveas(gcf,'MultiPlot12_dlLEPPPUSDof2017.png')
saveas(gcf,'MultiPlot12_dlLEPPPUSDof2017.epsc')


%%%%%%%%%%%%%%%%%%%%%%%


fig183 = figure

subplot(3,4,1)
plot(ticksCO2,data_CO2pcWorldMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average world LE per capita in PPP international USD of 2017')
title('World');

subplot(3,4,2)
plot(ticksCO2,data_CO2pcHiIncCsMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average HiIncCs LE per capita in PPP international USD of 2017')
title('High-Income Cs')

subplot(3,4,3)
plot(ticksCO2,data_CO2pcLoIncCsMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average LoIncCs LE per capita in PPP international USD of 2017')
title('Low-Income Cs')

subplot(3,4,4)
plot(ticksCO2,data_CO2pcUSMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('USLE per capita in PPP international USD of 2017')
title('US');

subplot(3,4,5)
plot(ticksCO2,data_CO2pcUKMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('UK LE per capita in PPP international USD of 2017')
title('UK');

subplot(3,4,6)
plot(ticksCO2,data_CO2pcEUMetricTons ,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('EU LE per capita in PPP international USD of 2017')
title('EU');

subplot(3,4,7)
plot(ticksCO2,data_CO2pcAUSMetricTons ,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('AUS LE per capita in PPP international USD of 2017')
title('Australia');

subplot(3,4,8)
plot(ticksCO2, data_CO2pcJPNMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('JPN LE per capita in PPP international USD of 2017')
title('Japan');

subplot(3,4,9)
plot(ticksCO2,data_CO2pcCHNMetricTons ,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('CHN LE per capita in PPP international USD of 2017')
title('China');

subplot(3,4,10)
plot(ticksCO2,data_CO2pcINDMetricTons ,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('IND LE per capita in PPP international USD of 2017')
title('India');

subplot(3,4,11)
plot(ticksCO2,data_CO2pcBRAMetricTons ,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('BRA LE per capita in PPP international USD of 2017')
title('Brazil');

subplot(3,4,12)
plot(ticksCO2,data_CO2pcMOZMetricTons,'LineWidth',2)
axis ([1990 2020 0 22])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('MOZ LE per capita in PPP international USD of 2017')
title('Mozambique');

saveas(gcf,'MultiPlot12_CO2pcMetricTons.fig')
saveas(gcf,'MultiPlot12_CO2pcMetricTons.png')
saveas(gcf,'MultiPlot12_CO2pcMetricTons.epsc')


%%%%%%%%%%%%%%%%%%%%%%%


fig184 = figure

subplot(3,4,1)
plot(ticksdlCO2,dldata_CO2pcWorldMetricTons,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average world LE per capita in PPP international USD of 2017')
title('World');

subplot(3,4,2)
plot(ticksdlCO2,dldata_CO2pcHiIncCsMetricTons, 'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('Average HiIncCs LE per capita in PPP international USD of 2017')
title('High-Income Cs')

subplot(3,4,3)
plot(ticksdlCO2,dldata_CO2pcLoIncCsMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('Average LoIncCs LE per capita in PPP international USD of 2017')
title('Low-Income Cs')

subplot(3,4,4)
plot(ticksdlCO2,dldata_CO2pcUSMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('US LE per capita in PPP international USD of 2017')
title('US');

subplot(3,4,5)
plot(ticksdlCO2,dldata_CO2pcUKMetricTons,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('UK LE per capita in PPP international USD of 2017')
title('UK');

subplot(3,4,6)
plot(ticksdlCO2,dldata_CO2pcEUMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('EU LE per capita in PPP international USD of 2017')
title('EU');

subplot(3,4,7)
plot(ticksdlCO2,dldata_CO2pcAUSMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('AUS LE per capita in PPP international USD of 2017')
title('Australia');

subplot(3,4,8)
plot(ticksdlCO2,dldata_CO2pcJPNMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('JPN LE per capita in PPP international USD of 2017')
title('Japan');

subplot(3,4,9)
plot(ticksdlCO2,dldata_CO2pcCHNMetricTons,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('CHN LE per capita in PPP international USD of 2017')
title('China');

subplot(3,4,10)
plot(ticksdlCO2,dldata_CO2pcINDMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('IND LE per capita in PPP international USD of 2017')
title('India');

subplot(3,4,11)
plot(ticksdlCO2,dldata_CO2pcBRAMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('BRA LE per capita in PPP international USD of 2017')
title('Brazil');

subplot(3,4,12)
plot(ticksdlCO2,dldata_CO2pcMOZMetricTons ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('MOZ LE per capita in PPP international USD of 2017')
title('Mozambique');

saveas(gcf,'MultiPlot12_dlCO2pcMetricTons.fig')
saveas(gcf,'MultiPlot12_dlCO2pcMetricTons.png')
saveas(gcf,'MultiPlot12_dlCO2pcMetricTons.epsc')


%%%%%%%%%%%%%%%%%%%%%%%


fig185 = figure

subplot(3,4,1)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcWorldDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average world greening prosperity ratio')
title('World)');

subplot(3,4,2)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcHiIncCsDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average HiIncCs LE per capita in PPP international USD of 2017')
title('High-Income Cs')

subplot(3,4,3)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcLoIncCsDefByLE ,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average LoIncCs LE per capita in PPP international USD of 2017')
title('Low-Income Cs')

subplot(3,4,4)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcUSDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('USLE per capita in PPP international USD of 2017')
title('US');

subplot(3,4,5)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcUKDefByLE ,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('UK LE per capita in PPP international USD of 2017')
title('UK');

subplot(3,4,6)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcEUDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('EU LE per capita in PPP international USD of 2017')
title('EU');

subplot(3,4,7)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcAUSDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('AUS LE per capita in PPP international USD of 2017')
title('Australia');

subplot(3,4,8)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcJPNDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('JPN LE per capita in PPP international USD of 2017')
title('Japan');

subplot(3,4,9)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcCHNDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('CHN LE per capita in PPP international USD of 2017')
title('China');

subplot(3,4,10)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcINDDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('IND LE per capita in PPP international USD of 2017')
title('India');

subplot(3,4,11)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcBRADefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('BRA LE per capita in PPP international USD of 2017')
title('Brazil');

subplot(3,4,12)
plot(ticksGreenProsppcWorldLE,data_GreenProsppcMOZDefByLE,'LineWidth',2)
axis ([1990 2020 0 12000])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('MOZ LE per capita in PPP international USD of 2017')
title('Mozambique');

saveas(gcf,'MultiPlot12_GreenProsppcDefByLE.fig')
saveas(gcf,'MultiPlot12_GreenProsppcDefByLE.png')
saveas(gcf,'MultiPlot12_GreenProsppcDefByLE.epsc')


%%%%%%%%%%%%%%%%%%%%%%%


fig186 = figure

subplot(3,4,1)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcWorldDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('average world LE per capita in PPP international USD of 2017')
title('World');

subplot(3,4,2)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcHiIncCsDefByLE, 'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('Average HiIncCs LE per capita in PPP international USD of 2017')
title('High-Income Cs')

subplot(3,4,3)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcLoIncCsDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('Average LoIncCs LE per capita in PPP international USD of 2017')
title('Low-Income Cs')

subplot(3,4,4)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcUSDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('US LE per capita in PPP international USD of 2017')
title('US');

subplot(3,4,5)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcUKDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('UK LE per capita in PPP international USD of 2017')
title('UK');

subplot(3,4,6)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcEUDefByLE ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('EU LE per capita in PPP international USD of 2017')
title('EU');

subplot(3,4,7)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcAUSDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('AUS LE per capita in PPP international USD of 2017')
title('Australia');

subplot(3,4,8)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcJPNDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('JPN LE per capita in PPP international USD of 2017')
title('Japan');

subplot(3,4,9)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcCHNDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('CHN LE per capita in PPP international USD of 2017')
title('China');

subplot(3,4,10)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcINDDefByLE ,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('IND LE per capita in PPP international USD of 2017')
title('India');

subplot(3,4,11)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcBRADefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('BRA LE per capita in PPP international USD of 2017')
title('Brazil');

subplot(3,4,12)
plot(ticksdlGreenProsppcWorldLE,dldata_GreenProsppcMOZDefByLE,'LineWidth',2)
axis ([1991 2020 -20 20])
fontsize(6,"points")
grid on
%xlabel('years (sample 1990-2020)')
%ylabel('MOZ LE per capita in PPP international USD of 2017')
title('Mozambique');

saveas(gcf,'MultiPlot12_dlGreenProsppcDefByLE.fig')
saveas(gcf,'MultiPlot12_dlGreenProsppcDefByLE.png')
saveas(gcf,'MultiPlot12_dlGreenProsppcDefByLE.epsc')


%%% AM231007 Trying (again) to fix the stripe colourmaps in multiplots %%%


fig187 = figure

subplot(3,4,1)
%fig1 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEWorld)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('Average World LE per capita in PPP IntlUSD of 2017 for 1990-1990');

subplot(3,4,2)
%fig16 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEHiIncCs)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('Average High-Income Countries LE per capita in PPP Intl USD of 2017 for 1990-1990');

subplot(3,4,3)
%fig31 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LELoIncCs)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('Average Low-Income Countries LE per capita in PPP Intl USD of 2017 for 1990-1990');

subplot(3,4,4)
%fig46 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEUS)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('US LE per capita in PPP Intl USD of 2017 for 1990-1990');

subplot(3,4,5)
%fig76 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEUK)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('UK');

subplot(3,4,6)
%fig136 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEEU)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('EU');

subplot(3,4,7)
%fig121 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEAUS)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('Australia');

subplot(3,4,8)
%fig166 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEJPN)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('Japan');

subplot(3,4,9)
%fig91 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LECHN)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('China');

subplot(3,4,10)
%fig151 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEIND)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('India');

subplot(3,4,11)
%fig106 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEBRA)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('Brazil');

subplot(3,4,12)
%fig61 = figure('Position',[100 100 800 300],...
   %'Color',[1 1 1])
axes(...
   'XLim',[min(ticksLE) max(ticksLE)],...
   'XTickMode','manual',...
   'XTick',ticksLE,...
   'XTickLabelRotation',90,...
   'YTick',[])
imagesc('XData',ticksLE',...
   'YData',[2000 2040],...
   'XData',[1990 2020],... %AM230630 Select the x-axis data vector (corresponding to the *.txt datafile) to be displayed!
   'CData',data_LEMOZ)   %AM230630 Select the data vector (from the *.txt datafile) to be displayed!
colormap(wscolors_EHWarming_BlueToRed)
colorbar
title('Mozambique');

saveas(gcf,'MultiPlot12_StripesLEPPPUSDof2017.fig')
saveas(gcf,'MultiPlot12_StripesLEPPPUSDof2017.png')
saveas(gcf,'MultiPlot12_StripesLEPPPUSDof2017.epsc')


%%%%%%%%%%%%%%%%%%%%%%%



%%% END of (long) program %%%